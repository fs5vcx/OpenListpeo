import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import os from "os";
import path from "path";
import fs from "fs";

// 服务启动时间
const serverStartTime = Date.now();
import crypto from "crypto";
import multer from "multer";
import sharp from "sharp";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import { config } from "./server-config";

// Use unified configurations
const dbPath = config.dbPath;
const uploadDir = config.uploadDir;
const chunksDir = path.join(uploadDir, "chunks");

// 辅助函数：相对路径转绝对路径
function getFullPath(relativePath: string): string {
  return path.join(uploadDir, relativePath);
}

// 辅助函数：绝对路径转相对路径
function toRelativePath(fullPath: string): string {
  return path.relative(uploadDir, fullPath);
}

// Initialize uploads and chunks directories
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
if (!fs.existsSync(chunksDir)) {
  fs.mkdirSync(chunksDir, { recursive: true });
}

// Initialize SQLite database
const db = new Database(dbPath);

// 数据库最佳安全配置
db.pragma("journal_mode = WAL");      // WAL 模式：最抗崩溃的写入方式
db.pragma("synchronous = FULL");      // 完全同步：每次写入都等磁盘完成，最安全
db.pragma("temp_store = MEMORY");     // 临时表存内存：提升性能
db.pragma("foreign_keys = ON");       // 开启外键约束：保证数据一致性

// Create tables if they don't exist
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    username TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS login_attempts (
    username TEXT PRIMARY KEY,
    attempts INTEGER DEFAULT 0,
    lockout_until TEXT
  );

  CREATE TABLE IF NOT EXISTS folders (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id TEXT, -- Empty string or NULL for root
    created_at TEXT NOT NULL,
    user_id TEXT,
    is_trashed INTEGER DEFAULT 0,
    content_hash TEXT
  );

  
  CREATE TABLE IF NOT EXISTS file_contents (
    content_hash TEXT PRIMARY KEY,
    path TEXT NOT NULL,
    size INTEGER NOT NULL,
    ref_count INTEGER DEFAULT 1,
    created_at TEXT NOT NULL,
    original_name TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    original_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size INTEGER NOT NULL,
    path TEXT NOT NULL,
    thumbnail_path TEXT,
    created_at TEXT NOT NULL,
    folder_id TEXT, -- Empty string or NULL for root
    is_favorite INTEGER DEFAULT 0,
    tags TEXT,
    user_id TEXT,
    is_trashed INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS shared_links (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    share_url TEXT NOT NULL,
    pikpak_id TEXT NOT NULL,
    size INTEGER DEFAULT 0,
    format TEXT,
    created_at TEXT NOT NULL,
    user_id TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Create index for shared_links table
db.exec(`
  CREATE INDEX IF NOT EXISTS idx_shared_links_user ON shared_links(user_id);
  CREATE INDEX IF NOT EXISTS idx_shared_links_name ON shared_links(name);
`);

// Safe column migrations for older DBs
try {
  db.exec("ALTER TABLE folders ADD COLUMN user_id TEXT");
} catch (e) {}

try {
  db.exec("ALTER TABLE files ADD COLUMN user_id TEXT");
} catch (e) {}

try {
  db.exec("ALTER TABLE folders ADD COLUMN is_trashed INTEGER DEFAULT 0");
} catch (e) {}

try {
  db.exec("ALTER TABLE files ADD COLUMN is_trashed INTEGER DEFAULT 0");
} catch (e) {}

try {
  db.exec("ALTER TABLE files ADD COLUMN content_hash TEXT");
} catch (e) {}

// Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueId = crypto.randomBytes(12).toString("hex");
    let originalName = file.originalname;
    try {
      originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
    } catch (e) {
      // ignore
    }
    const ext = path.extname(originalName);
    cb(null, `${uniqueId}${ext}`);
  },
});

const upload = multer({
  storage,
});

// Password hash helpers
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 100000, 64, "sha512").toString("hex");
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString("hex");
}

async function startServer() {
  const app = express();
  const PORT = config.port;

  app.use(express.json());

  // Seed user 'admin' with specific password
  try {
    const adminUsername = "admin";
    const adminPassword = "bn9^4a9B!7BbLdcONG1xIm!z$eaO%uHk";
    const existingAdmin = db.prepare("SELECT id FROM users WHERE username = ?").get(adminUsername) as any;
    const salt = generateSalt();
    const hash = hashPassword(adminPassword, salt);
    const now = new Date().toISOString();
    
    if (existingAdmin) {
      db.prepare("UPDATE users SET password_hash = ?, salt = ? WHERE username = ?").run(hash, salt, adminUsername);
      console.log("Admin password updated/verified during startup.");
    } else {
      const adminId = crypto.randomUUID();
      db.prepare("INSERT INTO users (id, username, password_hash, salt, created_at) VALUES (?, ?, ?, ?, ?)").run(
        adminId,
        adminUsername,
        hash,
        salt,
        now
      );
      console.log("Admin user seeded successfully during startup.");
    }
  } catch (e) {
    console.error("Error seeding admin user:", e);
  }

  // Authentication Middleware
  const authenticateUser = (req: any, res: any, next: any) => {
    try {
      let token = "";
      
      // 1. Authorization Header
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith("Bearer ")) {
        token = authHeader.substring(7);
      }
      
      // 2. Cookie
      if (!token && req.headers.cookie) {
        const match = req.headers.cookie.match(/session_token=([^;]+)/);
        if (match) {
          token = match[1];
        }
      }
      
      // 3. Query Param (useful for image previews and downloads)
      if (!token && req.query.token) {
        token = req.query.token as string;
      }

      if (!token) {
        return res.status(401).json({ error: "请先登录" });
      }

      const session = db.prepare("SELECT * FROM sessions WHERE token = ?").get(token) as any;
      if (!session) {
        return res.status(401).json({ error: "会话已失效，请重新登录" });
      }

      const expiresAt = new Date(session.expires_at);
      if (expiresAt < new Date()) {
        db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
        return res.status(401).json({ error: "会话已过期，请重新登录" });
      }

      req.user = {
        id: session.user_id,
        username: session.username,
        token: session.token,
      };
      next();
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  };

  // ==========================================
  // API: AUTHENTICATION
  // ==========================================

  app.get("/api/auth/status", (req, res) => {
    try {
      const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
      const hasUsers = userCount.count > 0;

      let loggedIn = false;
      let username = "";
      let userId = "";

      let token = "";
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith("Bearer ")) {
        token = authHeader.substring(7);
      }
      if (!token && req.headers.cookie) {
        const match = req.headers.cookie.match(/session_token=([^;]+)/);
        if (match) token = match[1];
      }
      if (!token && req.query.token) {
        token = req.query.token as string;
      }

      if (token) {
        const session = db.prepare("SELECT * FROM sessions WHERE token = ?").get(token) as any;
        if (session) {
          const expiresAt = new Date(session.expires_at);
          if (expiresAt > new Date()) {
            loggedIn = true;
            username = session.username;
            userId = session.user_id;
          } else {
            db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
          }
        }
      }

      res.json({
        hasUsers,
        loggedIn,
        user: loggedIn ? { id: userId, username } : null
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 注册接口已禁用
  app.post("/api/auth/register", (req, res) => {
    res.status(403).json({ error: "注册功能已关闭，请联系管理员" });
    return;
  });

    app.post("/api/auth/login", (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password || username.trim() === "" || password.trim() === "") {
        return res.status(400).json({ error: "用户名和密码不能为空" });
      }

      const u = username.trim();

      // Check brute-force lockout
      const attempt = db.prepare("SELECT * FROM login_attempts WHERE username = ?").get(u) as any;
      if (attempt && attempt.lockout_until) {
        const lockoutUntil = new Date(attempt.lockout_until);
        if (lockoutUntil > new Date()) {
          const secondsLeft = Math.ceil((lockoutUntil.getTime() - Date.now()) / 1000);
          return res.status(429).json({ error: `登录尝试次数过多。账户已锁定，请在 ${secondsLeft} 秒后重试。` });
        }
      }

      const user = db.prepare("SELECT * FROM users WHERE username = ?").get(u) as any;
      if (!user) {
        recordFailedAttempt(u, attempt);
        return res.status(401).json({ error: "用户名或密码错误" });
      }

      const hash = hashPassword(password, user.salt);
      if (hash !== user.password_hash) {
        recordFailedAttempt(u, attempt);
        return res.status(401).json({ error: "用户名或密码错误" });
      }

      // Success! Reset failed attempts
      db.prepare("DELETE FROM login_attempts WHERE username = ?").run(u);

      const token = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(); // 7 days
      db.prepare("INSERT INTO sessions (token, user_id, username, expires_at) VALUES (?, ?, ?, ?)").run(
        token,
        user.id,
        user.username,
        expiresAt
      );

      res.setHeader("Set-Cookie", `session_token=${token}; Path=/; HttpOnly; Max-Age=${7 * 24 * 60 * 60}; SameSite=Lax`);
      res.json({
        success: true,
        token,
        user: { id: user.id, username: user.username }
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  function recordFailedAttempt(username: string, attempt: any) {
    const maxAttempts = 5;
    const currentAttempts = attempt ? attempt.attempts + 1 : 1;
    let lockoutUntilStr: string | null = null;
    if (currentAttempts >= maxAttempts) {
      const lockoutTime = new Date(Date.now() + 60 * 1000); // 1 minute lockout
      lockoutUntilStr = lockoutTime.toISOString();
    }
    db.prepare(`
      INSERT INTO login_attempts (username, attempts, lockout_until)
      VALUES (?, ?, ?)
      ON CONFLICT(username) DO UPDATE SET attempts = ?, lockout_until = ?
    `).run(username, currentAttempts, lockoutUntilStr, currentAttempts, lockoutUntilStr);
  }

  app.post("/api/auth/logout", (req, res) => {
    try {
      let token = "";
      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith("Bearer ")) token = authHeader.substring(7);
      if (!token && req.headers.cookie) {
        const match = req.headers.cookie.match(/session_token=([^;]+)/);
        if (match) token = match[1];
      }

      if (token) {
        db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
      }

      res.setHeader("Set-Cookie", `session_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly`);
      res.json({ success: true, message: "已成功退出登录" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Reset all database files and folders for current user
  app.post("/api/system/reset", authenticateUser, (req: any, res) => {
    try {
      // 1. Get all files for this user
      const files = db.prepare("SELECT * FROM files WHERE user_id = ?").all(req.user.id) as any[];
      
      // 2. Delete all physical files (内容寻址模式）
      for (const file of files) {
        deletePhysicalFile(file);
      }

      // 3. Delete all file records from DB for this user
      db.prepare("DELETE FROM files WHERE user_id = ?").run(req.user.id);

      // 4. Delete all folder records from DB for this user
      db.prepare("DELETE FROM folders WHERE user_id = ?").run(req.user.id);

      res.json({ success: true, message: "所有数据库记录和已上传的文件已清空！" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // API: FOLDERS
  // ==========================================

  // Get list of folders inside a parent folder
  app.get("/api/folders", authenticateUser, (req: any, res) => {
    try {
      const parentId = (req.query.parentId as string) || "";
      const stmt = db.prepare("SELECT * FROM folders WHERE parent_id = ? AND user_id = ? AND (is_trashed IS NULL OR is_trashed = 0) ORDER BY name ASC");
      const folders = stmt.all(parentId, req.user.id);
      res.json(folders);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Create a new folder
  app.post("/api/folders", authenticateUser, (req: any, res) => {
    try {
      const { name, parentId } = req.body;
      if (!name || name.trim() === "") {
        return res.status(400).json({ error: "Folder name is required" });
      }
      const id = crypto.randomBytes(16).toString("hex");
      const createdAt = new Date().toISOString();
      const parent = parentId || "";

      const stmt = db.prepare(
        "INSERT INTO folders (id, name, parent_id, created_at, user_id) VALUES (?, ?, ?, ?, ?)"
      );
      stmt.run(id, name.trim(), parent, createdAt, req.user.id);

      res.status(201).json({ id, name: name.trim(), parent_id: parent, created_at: createdAt });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Rename folder
  app.put("/api/folders/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const { name } = req.body;
      if (!name || name.trim() === "") {
        return res.status(400).json({ error: "Folder name is required" });
      }

      const stmt = db.prepare("UPDATE folders SET name = ? WHERE id = ? AND user_id = ?");
      const result = stmt.run(name.trim(), id, req.user.id);

      if (result.changes === 0) {
        return res.status(404).json({ error: "Folder not found" });
      }
      res.json({ id, name: name.trim() });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ========== 文件元数据索引（用于数据恢复） ==========

  // 获取元数据文件路径
  function getMetadataPath(relativeFilePath: string): string {
    return path.join(uploadDir, `${relativeFilePath}.meta.json`);
  }

  // 写入/更新文件元数据索引文件
  function writeMetadataFile(file: any): void {
    try {
      const metaPath = getMetadataPath(file.path);
      const meta = {
        fileId: file.id,
        originalName: file.original_name || file.name,
        name: file.name,
        folderId: file.folder_id || "",
        size: file.size,
        mimeType: file.mime_type,
        contentHash: file.content_hash || "",
        uploadedAt: file.created_at,
        userId: file.user_id || "",
        isFavorite: file.is_favorite ? true : false,
        tags: file.tags || "",
        isTrashed: file.is_trashed ? true : false,
        indexedAt: new Date().toISOString()
      };
      fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2), "utf-8");
      console.log(`[元数据索引] 已写入: ${file.path}.meta.json`);
    } catch (e) {
      console.error("[元数据索引] 写入失败:", e);
    }
  }

  // 删除元数据索引文件
  function deleteMetadataFile(relativeFilePath: string): void {
    try {
      const metaPath = getMetadataPath(relativeFilePath);
      if (fs.existsSync(metaPath)) {
        fs.unlinkSync(metaPath);
        console.log(`[元数据索引] 已删除: ${relativeFilePath}.meta.json`);
      }
    } catch (e) {
      console.error("[元数据索引] 删除失败:", e);
    }
  }

  // 内容寻址：删除物理文件（处理引用计数）
  const deletePhysicalFile = (file: any) => {
    try {
      // 如果有 content_hash，走内容寻址逻辑
      if (file.content_hash) {
        const content = db.prepare(
          "SELECT * FROM file_contents WHERE content_hash = ?"
        ).get(file.content_hash) as any;

        if (content) {
          if (content.ref_count <= 1) {
            // 引用计数归零，删除物理文件和内容表记录
            try {
              if (fs.existsSync(getFullPath(content.path))) {
                fs.unlinkSync(getFullPath(content.path));
                // 删除元数据索引文件
                deleteMetadataFile(content.path);
              }
            } catch (e) {
              console.error("Error deleting physical file:", e);
            }
            db.prepare("DELETE FROM file_contents WHERE content_hash = ?").run(file.content_hash);
            console.log(`[内容寻址] 引用计数归零，删除物理文件: ${file.content_hash.substring(0, 16)}...`);
          } else {
            // 引用计数 > 1，只减少计数
            db.prepare(
              "UPDATE file_contents SET ref_count = ref_count - 1 WHERE content_hash = ?"
            ).run(file.content_hash);
            console.log(`[内容寻址] 引用计数 -1: ${file.content_hash.substring(0, 16)}... (剩余 ${content.ref_count - 1})`);
          }
        }
      } else {
        // 没有 content_hash，直接删除物理文件（旧文件）
        if (fs.existsSync(getFullPath(file.path))) {
          fs.unlinkSync(getFullPath(file.path));
          // 删除元数据索引文件
          deleteMetadataFile(file.path);
        }
      }

      // 删除缩略图（每个文件单独的缩略图）
      const thumbPath = path.join(uploadDir, "thumbnails", `${file.id}.webp`);
      if (fs.existsSync(thumbPath)) {
        fs.unlinkSync(thumbPath);
      }
    } catch (e) {
      console.error("Error in deletePhysicalFile:", e);
    }
  };

  // Recursively delete folder and its contents (permanent)
  const deleteFolderRecursive = (folderId: string, userId: string) => {
    // 1. Get all files in this folder and delete them
    const filesStmt = db.prepare("SELECT * FROM files WHERE folder_id = ? AND user_id = ?");
    const files = filesStmt.all(folderId, userId) as any[];
    for (const file of files) {
      deletePhysicalFile(file);
      db.prepare("DELETE FROM files WHERE id = ? AND user_id = ?").run(file.id, userId);
    }

    // 2. Get all subfolders and delete recursively
    const subfoldersStmt = db.prepare("SELECT id FROM folders WHERE parent_id = ? AND user_id = ?");
    const subfolders = subfoldersStmt.all(folderId, userId) as any[];
    for (const sub of subfolders) {
      deleteFolderRecursive(sub.id, userId);
    }

    // 3. Delete this folder itself
    db.prepare("DELETE FROM folders WHERE id = ? AND user_id = ?").run(folderId, userId);
  };

  // Recursively trash folder and its contents
  const trashFolderRecursive = (folderId: string, userId: string) => {
    // 1. Mark files as trashed
    db.prepare("UPDATE files SET is_trashed = 1 WHERE folder_id = ? AND user_id = ?").run(folderId, userId);

    // 更新这些文件的元数据索引
    const files = db.prepare("SELECT * FROM files WHERE folder_id = ? AND user_id = ?").all(folderId, userId) as any[];
    for (const file of files) {
      writeMetadataFile(file);
    }

    // 2. Get subfolders and trash recursively
    const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ? AND user_id = ?").all(folderId, userId) as any[];
    for (const sub of subfolders) {
      trashFolderRecursive(sub.id, userId);
    }

    // 3. Mark this folder itself as trashed
    db.prepare("UPDATE folders SET is_trashed = 1 WHERE id = ? AND user_id = ?").run(folderId, userId);
  };

  // Recursively restore folder and its contents
  const restoreFolderRecursive = (folderId: string, userId: string) => {
    // 1. Mark files as restored
    db.prepare("UPDATE files SET is_trashed = 0 WHERE folder_id = ? AND user_id = ?").run(folderId, userId);

    // 2. Get subfolders and restore recursively
    const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ? AND user_id = ?").all(folderId, userId) as any[];
    for (const sub of subfolders) {
      restoreFolderRecursive(sub.id, userId);
    }

    // 3. Mark this folder itself as restored
    db.prepare("UPDATE folders SET is_trashed = 0 WHERE id = ? AND user_id = ?").run(folderId, userId);
  };

  // Delete folder (move to trash)
  app.delete("/api/folders/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      trashFolderRecursive(id, req.user.id);
      res.json({ success: true, message: "Folder and all its contents moved to trash" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // ==========================================
  // API: FILES
  // ==========================================

  // Get files with filtering and sorting (supports pagination)
  app.get("/api/files", authenticateUser, (req: any, res) => {
    try {
      const folderId = (req.query.folderId as string) || "";
      const isFavorite = req.query.isFavorite === "true";
      const search = (req.query.search as string) || "";
      const type = (req.query.type as string) || "all"; // all, images, videos, audio, documents, others
      const sortField = (req.query.sortField as string) || "created_at"; // name, size, created_at
      const sortOrder = (req.query.sortOrder as string) || "DESC"; // ASC, DESC
      
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 12; // Default to 12 files per page

      let query = "SELECT id, name, original_name, mime_type, size, thumbnail_path, created_at, folder_id, is_favorite, tags, is_trashed FROM files WHERE user_id = ? AND (is_trashed IS NULL OR is_trashed = 0)";
      const params: any[] = [req.user.id];

      // If we are searching or viewing favorites, search globally for this user
      if (search) {
        query += " AND name LIKE ?";
        params.push(`%${search}%`);
      } else if (isFavorite) {
        query += " AND is_favorite = 1";
      } else if (folderId === "" && type !== "all") {
        // 根目录下快速过滤时，全局搜索（因为根目录没文件，文件都在子目录）
        // 不添加 folder_id 限制
      } else {
        // 其他情况（查看全部文件，或在子文件夹里快速过滤），按文件夹筛选
        query += " AND folder_id = ?";
        params.push(folderId);
      }

      // Filter by mime type categories
      if (type !== "all") {
        if (type === "images") {
          query += " AND mime_type LIKE 'image/%'";
        } else if (type === "videos") {
          query += " AND mime_type LIKE 'video/%'";
        } else if (type === "audio") {
          query += " AND mime_type LIKE 'audio/%'";
        } else if (type === "documents") {
          query += " AND (mime_type LIKE 'text/%' OR mime_type = 'application/pdf' OR mime_type LIKE '%word%' OR mime_type LIKE '%excel%' OR mime_type LIKE '%powerpoint%' OR mime_type LIKE '%zip%' OR mime_type LIKE '%rar%')";
        } else if (type === "others") {
          query += " AND NOT (mime_type LIKE 'image/%' OR mime_type LIKE 'video/%' OR mime_type LIKE 'audio/%' OR mime_type LIKE 'text/%' OR mime_type = 'application/pdf' OR mime_type LIKE '%word%' OR mime_type LIKE '%excel%' OR mime_type LIKE '%powerpoint%' OR mime_type LIKE '%zip%' OR mime_type LIKE '%rar%')";
        }
      }

      // Validate sort field
      const validFields = ["name", "size", "created_at"];
      const orderField = validFields.includes(sortField) ? sortField : "created_at";
      const orderDir = sortOrder.toUpperCase() === "ASC" ? "ASC" : "DESC";

      query += ` ORDER BY ${orderField} ${orderDir}`;

      // Get total count for pagination
      const countQuery = `SELECT COUNT(*) as count FROM (${query})`;
      const countStmt = db.prepare(countQuery);
      const totalRow = countStmt.get(...params) as { count: number };
      const total = totalRow ? totalRow.count : 0;

      // Add LIMIT and OFFSET for pagination
      const offset = (page - 1) * limit;
      query += " LIMIT ? OFFSET ?";
      const paginatedParams = [...params, limit, offset];

      const stmt = db.prepare(query);
      const files = stmt.all(...paginatedParams);
      
      const hasMore = offset + files.length < total;

      // Search folders too when searching
      let folders: any[] = [];
      if (search) {
        const folderQuery = "SELECT id, name, parent_id, created_at FROM folders WHERE user_id = ? AND (is_trashed IS NULL OR is_trashed = 0) AND name LIKE ? ORDER BY name ASC";
        const folderStmt = db.prepare(folderQuery);
        folders = folderStmt.all(req.user.id, `%${search}%`);
      }

      res.json({
        files,
        folders,
        total,
        page,
        limit,
        hasMore
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Initiate chunked / resumable upload session
  app.post("/api/files/upload/init", authenticateUser, (req: any, res) => {
    try {
      const { filename, fileSize, mimeType, folderId } = req.body;
      if (!filename || fileSize === undefined) {
        return res.status(400).json({ error: "Missing filename or fileSize" });
      }

      const fid = folderId || "";
      // Generate a secure, user-specific upload key based on metadata
      const sessionKey = crypto
        .createHash("sha256")
        .update(`${req.user.id}-${filename}-${fileSize}-${fid}`)
        .digest("hex");

      const sessionDir = path.join(chunksDir, sessionKey);
      if (!fs.existsSync(sessionDir)) {
        fs.mkdirSync(sessionDir, { recursive: true });
      }

      // Scan directory for existing chunks
      const filesInDir = fs.readdirSync(sessionDir);
      const uploadedChunks = filesInDir
        .filter(f => f.startsWith("chunk_"))
        .map(f => parseInt(f.replace("chunk_", ""), 10))
        .filter(n => !isNaN(n));

      res.json({
        sessionId: sessionKey,
        uploadedChunks
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Upload an individual chunk
  app.post("/api/files/upload/chunk", authenticateUser, upload.single("chunk"), (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No chunk file received" });
      }

      const { sessionId, chunkNumber } = req.body;
      if (!sessionId || chunkNumber === undefined) {
        if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        return res.status(400).json({ error: "Missing sessionId or chunkNumber" });
      }

      // Safety check for sessionId to avoid directory traversal
      if (!/^[a-f0-9]{64}$/.test(sessionId)) {
        if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
        return res.status(400).json({ error: "Invalid sessionId format" });
      }

      const sessionDir = path.join(chunksDir, sessionId);
      if (!fs.existsSync(sessionDir)) {
        fs.mkdirSync(sessionDir, { recursive: true });
      }

      const chunkPath = path.join(sessionDir, `chunk_${chunkNumber}`);
      fs.renameSync(req.file.path, chunkPath);

      res.json({ success: true, chunkNumber: parseInt(chunkNumber, 10) });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Merge uploaded chunks into the final file
  app.post("/api/files/upload/merge", authenticateUser, (req: any, res) => {
    try {
      const { sessionId, filename, mimeType, folderId, totalChunks } = req.body;
      if (!sessionId || !filename || !totalChunks || !mimeType) {
        return res.status(400).json({ error: "Missing merge parameters" });
      }

      // Safety check for sessionId
      if (!/^[a-f0-9]{64}$/.test(sessionId)) {
        return res.status(400).json({ error: "Invalid sessionId format" });
      }

      const sessionDir = path.join(chunksDir, sessionId);
      if (!fs.existsSync(sessionDir)) {
        return res.status(400).json({ error: "Upload session not found" });
      }

      // Verify all chunks exist
      const missingChunks: number[] = [];
      for (let i = 0; i < totalChunks; i++) {
        const chunkPath = path.join(sessionDir, `chunk_${i}`);
        if (!fs.existsSync(chunkPath)) {
          missingChunks.push(i);
        }
      }

      if (missingChunks.length > 0) {
        return res.status(400).json({
          error: "Some chunks are missing",
          missingChunks
        });
      }

      // Create final file path
      const fileId = crypto.randomBytes(16).toString("hex");
      const uniqueId = crypto.randomBytes(12).toString("hex");
      const ext = path.extname(filename);
      const finalFilename = `${uniqueId}${ext}`;
      const finalFilePath = path.join(uploadDir, finalFilename);

      // Concatenate chunks
      const writeStream = fs.createWriteStream(finalFilePath);

      for (let i = 0; i < totalChunks; i++) {
        const chunkPath = path.join(sessionDir, `chunk_${i}`);
        const chunkData = fs.readFileSync(chunkPath);
        writeStream.write(chunkData);
      }
      writeStream.end();

      // After finish writing, get stats and add to DB
      writeStream.on("finish", () => {
        try {
          const stats = fs.statSync(finalFilePath);
          const createdAt = new Date().toISOString();
          const fid = folderId || "";

          let thumbnailPath = "";
          if (mimeType.startsWith("image/")) {
            thumbnailPath = `/api/files/raw/${fileId}`;
          } else if (mimeType.startsWith("video/")) {
            // 生成视频缩略图
            thumbnailPath = `/api/files/thumbnail/${fileId}`;
          }

          const stmt = db.prepare(`
            INSERT INTO files (id, name, original_name, mime_type, size, path, thumbnail_path, created_at, folder_id, is_favorite, tags, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, '', ?)
          `);

          stmt.run(
            fileId,
            filename,
            filename,
            mimeType,
            stats.size,
            toRelativePath(finalFilePath),
            thumbnailPath,
            createdAt,
            fid,
            req.user.id
          );

          // Clean up chunks
          try {
            for (let i = 0; i < totalChunks; i++) {
              const chunkPath = path.join(sessionDir, `chunk_${i}`);
              if (fs.existsSync(chunkPath)) fs.unlinkSync(chunkPath);
            }
            fs.rmdirSync(sessionDir);
          } catch (cleanupErr) {
            console.error("Error during chunks clean-up:", cleanupErr);
          }

          const uploadedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(fileId, req.user.id);

          // 写入元数据索引文件（用于数据恢复）
          writeMetadataFile(uploadedFile);

          res.status(201).json(uploadedFile);
        } catch (dbErr: any) {
          res.status(500).json({ error: dbErr.message });
        }
      });

      writeStream.on("error", (streamErr: any) => {
        res.status(500).json({ error: "Error writing final file: " + streamErr.message });
      });

    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ========== 断点续传（流式追加）方案 ==========
  // 适合 Cloudflare 隧道等大文件上传受限的场景
  // 优势：10MB 分片、串行上传、流式追加、无需最后合并、支持断点续传

  const resumableDir = path.join(chunksDir, "resumable");
  if (!fs.existsSync(resumableDir)) {
    fs.mkdirSync(resumableDir, { recursive: true });
  }

  // 生成安全的 fileId（防止路径遍历）
  function getSafeResumablePath(fileId: string, userId: string): string {
    // 用户隔离 + fileId 哈希，确保安全
    const safeId = crypto.createHash("sha256").update(`${userId}-${fileId}`).digest("hex");
    return path.join(resumableDir, safeId);
  }

  // 接口 1：检查上传状态（断点续传的核心）
  app.get("/api/files/upload/status", authenticateUser, (req: any, res) => {
    try {
      const { fileId } = req.query;
      if (!fileId) {
        return res.status(400).json({ error: "缺少 fileId" });
      }

      const filePath = getSafeResumablePath(fileId as string, req.user.id);

      // 如果文件已存在，返回它当前的大小（字节数）
      if (fs.existsSync(filePath)) {
        const stat = fs.statSync(filePath);
        return res.json({ uploadedBytes: stat.size });
      }

      // 如果文件不存在，说明是全新上传
      return res.json({ uploadedBytes: 0 });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 接口 2：接收分片并流式追加
  // 注意：这里不用 multer，直接接住 Data Stream 并 Append
  app.post("/api/files/upload/append", authenticateUser, (req: any, res) => {
    try {
      // 从 Header 中获取元数据
      const fileId = req.headers["x-file-id"] as string;
      const startByte = parseInt(req.headers["x-start-byte"] as string, 10);

      if (!fileId || isNaN(startByte)) {
        return res.status(400).json({ error: "请求头信息不完整" });
      }

      const filePath = getSafeResumablePath(fileId, req.user.id);

      // 检查服务器文件的当前大小，防止前端并发乱序或者重复发送
      let currentSize = 0;
      if (fs.existsSync(filePath)) {
        currentSize = fs.statSync(filePath).size;
      }

      // 如果前端声明的起始写入位置和后端当前文件大小对不上，说明乱序了
      if (startByte !== currentSize) {
        return res.status(409).json({
          error: "文件指针不匹配，请重新获取状态",
          expectedByte: currentSize
        });
      }

      // 核心：使用 flags: 'a' (Append) 开启追加模式的文件写入流
      const writeStream = fs.createWriteStream(filePath, { flags: "a" });
      let responded = false;

      // 安全发送响应（确保只发送一次）
      const sendResponse = (statusCode: number, data: any) => {
        if (responded || res.headersSent) return;
        responded = true;
        try {
          res.status(statusCode).json(data);
        } catch (err) {
          console.error("发送响应失败:", err);
        }
      };

      // 把请求体的二进制数据流导向（pipe）到目标文件
      req.pipe(writeStream);

      let finalSize = currentSize;

      writeStream.on("finish", () => {
        // 写入完成，记录文件大小（数据已刷新到内核缓冲区）
        try {
          finalSize = fs.statSync(filePath).size;
        } catch (err) {
          console.error("[append] finish 时读取文件大小失败:", err);
        }
      });

      writeStream.on("close", () => {
        // 文件描述符完全关闭后再发送响应，确保数据已落盘
        if (!responded && !res.headersSent) {
          try {
            // 最终确认文件大小
            if (fs.existsSync(filePath)) {
              finalSize = fs.statSync(filePath).size;
            }
            sendResponse(200, { success: true, uploadedBytes: finalSize });
          } catch (err) {
            console.error("[append] close 时读取文件大小失败:", err);
            sendResponse(500, { error: "服务器写入失败" });
          }
        }
      });

      writeStream.on("error", (err) => {
        console.error("[append] 写入失败:", err);
        sendResponse(500, { error: "服务器写入失败" });
      });

      // 处理请求异常断开
      req.on("error", (err) => {
        console.error("请求错误:", err.message);
        writeStream.destroy();
        sendResponse(500, { error: "连接中断" });
      });

      req.on("close", () => {
        // 只有在未响应且请求异常中断时才销毁流
        // req.readableAborted = true 表示客户端异常断开
        // req.readableEnded = true 表示请求正常结束，让 writeStream 自己触发 finish
        if (!responded && req.readableAborted) {
          console.log("客户端异常断开，中止写入");
          writeStream.destroy();
          sendResponse(500, { error: "连接中断" });
        }
      });

    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 接口 3：上传完成，将文件移动到正式目录并写入数据库
  app.post("/api/files/upload/complete", authenticateUser, (req: any, res) => {
    try {
      const { fileId, filename, mimeType, folderId } = req.body;

      if (!fileId || !filename || !mimeType) {
        return res.status(400).json({ error: "缺少必要参数" });
      }

      const tempFilePath = getSafeResumablePath(fileId, req.user.id);

      if (!fs.existsSync(tempFilePath)) {
        return res.status(400).json({ error: "上传文件不存在" });
      }

      // 生成最终文件信息
      const finalFileId = crypto.randomBytes(16).toString("hex");
      const uniqueId = crypto.randomBytes(12).toString("hex");
      const ext = path.extname(filename);
      const finalFilename = `${uniqueId}${ext}`;
      const finalFilePath = path.join(uploadDir, finalFilename);
      const fid = folderId || "";

      // 移动文件到正式目录
      fs.renameSync(tempFilePath, finalFilePath);

      // 计算文件真实 SHA256 哈希
      const fileBuffer = fs.readFileSync(finalFilePath);
      const contentHash = crypto.createHash('sha256').update(fileBuffer).digest('hex');

      // 获取文件信息
      const stats = fs.statSync(finalFilePath);
      const createdAt = new Date().toISOString();

      // 生成缩略图（图片文件）
      let thumbnailPath = "";
      if (mimeType.startsWith("image/")) {
        thumbnailPath = `/api/files/raw/${finalFileId}`;
      }

      // 【关键修复】先检查：当前文件夹下是否已有相同内容的虚拟文件
      const existingVirtualFile = db.prepare(
        "SELECT * FROM files WHERE folder_id = ? AND content_hash = ? AND user_id = ?"
      ).get(fid, contentHash, req.user.id) as any;

      if (existingVirtualFile) {
        // 同目录下已存在相同内容，删除刚上传的临时文件，直接返回已有记录（不创建新记录、不增 ref_count）
        console.log(`[去重] 同目录已存在相同内容，直接返回: ${filename} (folder: ${fid || "根目录"}, hash: ${contentHash.substring(0,16)}...)`);
        fs.unlinkSync(finalFilePath);
        return res.status(200).json(existingVirtualFile);
      }

      // 内容寻址：检查物理存储层是否已有相同内容
      const existingContent = db.prepare(
        "SELECT * FROM file_contents WHERE content_hash = ?"
      ).get(contentHash) as any;

      let finalRelativePath = toRelativePath(finalFilePath);

      if (existingContent) {
        // 物理层已有相同内容，复用物理文件
        console.log(`[内容寻址] 发现相同内容文件，复用物理存储: ${contentHash.substring(0, 16)}...`);
        // 删除刚上传的新文件（重复了）
        fs.unlinkSync(finalFilePath);
        // 增加引用计数
        db.prepare(
          "UPDATE file_contents SET ref_count = ref_count + 1 WHERE content_hash = ?"
        ).run(contentHash);
        // 使用已有的文件路径
        finalRelativePath = existingContent.path;
      } else {
        // 新内容，插入内容表
        db.prepare(`
          INSERT INTO file_contents (content_hash, path, size, ref_count, created_at, original_name)
          VALUES (?, ?, ?, 1, ?, ?)
        `).run(contentHash, finalRelativePath, stats.size, createdAt, filename);
      }

      // 写入文件记录
      const stmt = db.prepare(`
        INSERT INTO files (id, name, original_name, mime_type, size, path, thumbnail_path, created_at, folder_id, is_favorite, tags, user_id, content_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, '', ?, ?)
      `);

      stmt.run(
        finalFileId,
        filename,
        filename,
        mimeType,
        stats.size,
        finalRelativePath,
        thumbnailPath,
        createdAt,
        fid,
        req.user.id,
        contentHash
      );

      // 返回上传的文件信息
      const uploadedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(finalFileId, req.user.id);

      // 详细日志
      console.log(`[上传完成] 用户: ${req.user.username}, 文件名: ${filename}, 大小: ${(stats.size / 1024 / 1024).toFixed(2)} MB, 类型: ${mimeType}, 文件夹: ${fid || "根目录"}, 文件ID: ${finalFileId}`);

      // 写入元数据索引文件（用于数据恢复）
      writeMetadataFile(uploadedFile);

      res.status(201).json(uploadedFile);

    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 接口 4：秒传（检查是否已有相同文件，有则直接复用）
  app.post("/api/files/upload/quick", authenticateUser, (req: any, res) => {
    try {
      const { fileHash, filename, mimeType, folderId } = req.body;

      if (!fileHash || !filename || !mimeType) {
        return res.status(400).json({ error: "缺少必要参数" });
      }

      const fid = folderId || "";

      // 【正确顺序】先查物理层：内容表中是否已有相同哈希的内容
      const existingContent = db.prepare(
        "SELECT * FROM file_contents WHERE content_hash = ?"
      ).get(fileHash) as any;

      if (!existingContent) {
        // 物理层没有相同内容，需要正常上传
        return res.json({ exists: false });
      }

      // 2. 检查物理文件是否真实存在
      if (!fs.existsSync(getFullPath(existingContent.path))) {
        return res.json({ exists: false });
      }

      // 3. 物理层已有内容，再查虚拟层：当前文件夹下是否已有相同内容的虚拟文件
      const existingVirtualFile = db.prepare(
        "SELECT * FROM files WHERE folder_id = ? AND content_hash = ? AND user_id = ?"
      ).get(fid, fileHash, req.user.id) as any;

      if (existingVirtualFile) {
        // 同目录已存在相同虚拟文件，直接返回（不创建新记录、不增 ref_count）
        console.log(`[秒传去重] 同目录已存在相同内容，直接返回: ${filename} (folder: ${fid || "根目录"})`);
        return res.status(200).json({ exists: true, file: existingVirtualFile });
      }

      // 4. 跨目录秒传：创建新虚拟文件记录，复用物理存储，增加引用计数
      const finalFileId = crypto.randomBytes(16).toString("hex");
      const createdAt = new Date().toISOString();

      // 增加引用计数
      db.prepare(
        "UPDATE file_contents SET ref_count = ref_count + 1 WHERE content_hash = ?"
      ).run(fileHash);

      console.log(`[秒传成功] 内容寻址复用，引用计数 +1: ${fileHash.substring(0, 16)}...`);

      // 5. 生成缩略图路径
      let thumbnailPath = "";
      if (mimeType.startsWith("image/")) {
        thumbnailPath = `/api/files/raw/${finalFileId}`;
      }

      // 6. 写入文件记录（复用已有的物理文件路径）
      const stmt = db.prepare(`
        INSERT INTO files (id, name, original_name, mime_type, size, path, thumbnail_path, created_at, folder_id, is_favorite, tags, user_id, content_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, '', ?, ?)
      `);

      stmt.run(
        finalFileId,
        filename,
        filename,
        mimeType,
        existingContent.size,
        existingContent.path,
        thumbnailPath,
        createdAt,
        fid,
        req.user.id,
        fileHash
      );

      // 7. 返回秒传成功
      const uploadedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(finalFileId, req.user.id);

      console.log(`[秒传成功] 用户: ${req.user.username}, 文件名: ${filename}, 大小: ${(existingContent.size / 1024 / 1024).toFixed(2)} MB, 文件夹: ${fid || "根目录"}`);

      // 写入元数据索引文件（用于数据恢复）
      writeMetadataFile(uploadedFile);

      res.status(201).json({
        exists: true,
        file: uploadedFile
      });

    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ========== 断点续传方案结束 ==========


  // Upload file with detailed logging
  app.post("/api/files/upload", authenticateUser, (req: any, res, next) => {
    // 记录上传开始时间
    req.uploadStartTime = Date.now();
    next();
  }, upload.single("file"), (req: any, res) => {
    const endTime = Date.now();
    const startTime = req.uploadStartTime || endTime;
    const durationMs = endTime - startTime;
    const durationSec = durationMs / 1000;

    try {
      if (!req.file) {
        console.log(`[UPLOAD] ❌ 失败: 用户=${req.user?.username}, 原因=没有文件`);
        return res.status(400).json({ error: "No file was uploaded" });
      }

      const folderId = req.body.folderId || "";
      const fileId = crypto.randomBytes(16).toString("hex");
      const createdAt = new Date().toISOString();

      let decodedOriginalName = req.file.originalname;
      try {
        decodedOriginalName = Buffer.from(req.file.originalname, 'latin1').toString('utf8');
      } catch (e) {
        // ignore
      }

      // 计算上传速度
      const fileSizeBytes = req.file.size;
      const fileSizeKB = fileSizeBytes / 1024;
      const fileSizeMB = fileSizeKB / 1024;
      let speedStr: string;
      if (durationSec > 0) {
        const bytesPerSec = fileSizeBytes / durationSec;
        if (bytesPerSec >= 1024 * 1024) {
          speedStr = (bytesPerSec / (1024 * 1024)).toFixed(2) + ' MB/s';
        } else if (bytesPerSec >= 1024) {
          speedStr = (bytesPerSec / 1024).toFixed(1) + ' KB/s';
        } else {
          speedStr = bytesPerSec.toFixed(0) + ' B/s';
        }
      } else {
        speedStr = '极快 (< 1ms)';
      }

      // 格式化文件大小
      let sizeStr: string;
      if (fileSizeMB >= 1) {
        sizeStr = fileSizeMB.toFixed(2) + ' MB';
      } else if (fileSizeKB >= 1) {
        sizeStr = fileSizeKB.toFixed(1) + ' KB';
      } else {
        sizeStr = fileSizeBytes + ' B';
      }

      // 输出详细上传日志
      console.log(`[UPLOAD] ✅ 成功`);
      console.log(`  用户: ${req.user?.username}`);
      console.log(`  文件名: ${decodedOriginalName}`);
      console.log(`  文件大小: ${sizeStr} (${fileSizeBytes} bytes)`);
      console.log(`  文件类型: ${req.file.mimetype}`);
      console.log(`  目标文件夹: ${folderId || '根目录'}`);
      console.log(`  耗时: ${durationMs}ms (${durationSec.toFixed(3)}s)`);
      console.log(`  上传速度: ${speedStr}`);
      console.log(`  文件ID: ${fileId}`);

      // For images, we can set thumbnail path directly to the view endpoint for convenience
      let thumbnailPath = "";
      if (req.file.mimetype.startsWith("image/")) {
        thumbnailPath = `/api/files/raw/${fileId}`;
      }

      // 计算文件内容 SHA256 哈希用于去重
      const fileBuffer = fs.readFileSync(req.file.path);
      const contentHash = crypto.createHash('sha256').update(fileBuffer).digest('hex');

      // 【关键修复】先检查：当前文件夹下是否已有相同内容的虚拟文件
      const existingVirtualFile = db.prepare(
        "SELECT * FROM files WHERE folder_id = ? AND content_hash = ? AND user_id = ?"
      ).get(folderId, contentHash, req.user.id) as any;

      if (existingVirtualFile) {
        // 同目录下已存在相同内容，删除刚上传的临时文件，直接返回已有记录
        console.log(`[去重] Multer同目录已存在相同内容，直接返回: ${decodedOriginalName} (folder: ${folderId || "根目录"})`);
        fs.unlinkSync(req.file.path);
        return res.status(200).json(existingVirtualFile);
      }

      // 内容寻址去重：检查物理存储层是否已有相同内容
      const existingContent = db.prepare(
        "SELECT * FROM file_contents WHERE content_hash = ?"
      ).get(contentHash) as any;

      let finalRelativePath = toRelativePath(req.file.path);

      if (existingContent) {
        // 已有相同内容，复用现有物理文件
        console.log(`[内容寻址] Multer上传发现相同内容，复用: ${contentHash.substring(0, 16)}...`);
        // 删除刚上传的重复文件
        fs.unlinkSync(req.file.path);
        // 增加引用计数
        db.prepare(
          "UPDATE file_contents SET ref_count = ref_count + 1 WHERE content_hash = ?"
        ).run(contentHash);
        // 使用已有的文件路径
        finalRelativePath = existingContent.path;
      } else {
        // 新内容，插入内容表
        db.prepare(`
          INSERT INTO file_contents (content_hash, path, size, ref_count, created_at, original_name)
          VALUES (?, ?, ?, 1, ?, ?)
        `).run(contentHash, finalRelativePath, req.file.size, createdAt, decodedOriginalName);
      }

      const stmt = db.prepare(`
        INSERT INTO files (id, name, original_name, mime_type, size, path, thumbnail_path, created_at, folder_id, is_favorite, tags, user_id, content_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, '', ?, ?)
      `);

      stmt.run(
        fileId,
        decodedOriginalName,
        decodedOriginalName,
        req.file.mimetype,
        req.file.size,
        finalRelativePath,
        thumbnailPath,
        createdAt,
        folderId,
        req.user.id,
        contentHash
      );

      const uploadedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(fileId, req.user.id);

      // 写入元数据索引文件（用于数据恢复）
      writeMetadataFile(uploadedFile);

      res.status(201).json(uploadedFile);
    } catch (err: any) {
      console.log(`[UPLOAD] ❌ 失败: 用户=${req.user?.username}, 错误=${err.message}`);
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });


  // Stream / View a file (supports range queries natively via Express sending static)
  app.get("/api/files/raw/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      if (!fs.existsSync(getFullPath(file.path))) {
        return res.status(404).json({ error: "Physical file missing on server" });
      }

      // Serve with correct content-type so videos and images play inline
      res.setHeader("Content-Type", file.mime_type);
      res.setHeader("Content-Disposition", `inline; filename="${encodeURIComponent(file.name)}"; filename*=UTF-8''${encodeURIComponent(file.name)}`);
      
      // Add Cache-Control header: private to protect user privacy (authenticated sessions), and long max-age since files are immutable by ID
      res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
      
      res.sendFile(getFullPath(file.path));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Download a file
  app.get("/api/files/download/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      if (!fs.existsSync(getFullPath(file.path))) {
        return res.status(404).json({ error: "Physical file missing on server" });
      }

      res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(file.name)}"; filename*=UTF-8''${encodeURIComponent(file.name)}`);
      res.setHeader("Content-Type", file.mime_type || "application/octet-stream");
      res.sendFile(getFullPath(file.path));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Delete file (move to trash)
  app.delete("/api/files/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      db.prepare("UPDATE files SET is_trashed = 1 WHERE id = ? AND user_id = ?").run(id, req.user.id);

      // 更新元数据索引文件（标记为已删除）
      const updatedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id);
      writeMetadataFile(updatedFile);

      res.json({ success: true, message: "File moved to trash" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update file (Rename, toggle Favorite, change Tags)
  app.put("/api/files/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const { name, isFavorite, tags } = req.body;

      // Build dynamic update
      const updates: string[] = [];
      const params: any[] = [];

      if (name !== undefined) {
        if (!name || name.trim() === "") {
          return res.status(400).json({ error: "File name cannot be empty" });
        }
        updates.push("name = ?");
        params.push(name.trim());
      }

      if (isFavorite !== undefined) {
        updates.push("is_favorite = ?");
        params.push(isFavorite ? 1 : 0);
      }

      if (tags !== undefined) {
        updates.push("tags = ?");
        params.push(tags);
      }

      if (updates.length === 0) {
        return res.status(400).json({ error: "No update parameters provided" });
      }

      params.push(id);
      params.push(req.user.id);
      const query = `UPDATE files SET ${updates.join(", ")} WHERE id = ? AND user_id = ?`;
      const result = db.prepare(query).run(...params);

      if (result.changes === 0) {
        return res.status(404).json({ error: "File not found" });
      }

      const updatedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id);

      // 更新元数据索引文件
      writeMetadataFile(updatedFile);

      res.json(updatedFile);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get statistics: storage used and file types
  app.get("/api/stats", authenticateUser, (req: any, res) => {
    try {
      // Total files size
      const totalSizeResult = db.prepare("SELECT SUM(size) as total FROM files WHERE user_id = ?").get(req.user.id) as any;
      const totalSize = totalSizeResult ? (totalSizeResult.total || 0) : 0;

      // File count
      const totalCountResult = db.prepare("SELECT COUNT(*) as count FROM files WHERE user_id = ?").get(req.user.id) as any;
      const totalCount = totalCountResult ? (totalCountResult.count || 0) : 0;

      // Group by categories
      const allFiles = db.prepare("SELECT mime_type, size FROM files WHERE user_id = ?").all(req.user.id) as any[];

      let imagesSize = 0;
      let imagesCount = 0;
      let videosSize = 0;
      let videosCount = 0;
      let audioSize = 0;
      let audioCount = 0;
      let docsSize = 0;
      let docsCount = 0;
      let othersSize = 0;
      let othersCount = 0;

      for (const f of allFiles) {
        const mime = f.mime_type || "";
        const size = f.size || 0;

        if (mime.startsWith("image/")) {
          imagesSize += size;
          imagesCount++;
        } else if (mime.startsWith("video/")) {
          videosSize += size;
          videosCount++;
        } else if (mime.startsWith("audio/")) {
          audioSize += size;
          audioCount++;
        } else if (
          mime.startsWith("text/") ||
          mime === "application/pdf" ||
          mime.includes("word") ||
          mime.includes("excel") ||
          mime.includes("powerpoint") ||
          mime.includes("zip") ||
          mime.includes("rar")
        ) {
          docsSize += size;
          docsCount++;
        } else {
          othersSize += size;
          othersCount++;
        }
      }

      res.json({
        totalSize,
        totalCount,
        categories: {
          images: { size: imagesSize, count: imagesCount },
          videos: { size: videosSize, count: videosCount },
          audio: { size: audioSize, count: audioCount },
          documents: { size: docsSize, count: docsCount },
          others: { size: othersSize, count: othersCount },
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Text reader helper
  app.get("/api/files/text/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      if (!fs.existsSync(getFullPath(file.path))) {
        return res.status(404).json({ error: "Physical file missing on server" });
      }

      const text = fs.readFileSync(getFullPath(file.path), "utf-8");
      res.json({ text });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // ==========================================
  // API: TRASH & EXTRA FILE OPERATIONS
  // ==========================================

  // Get all trashed folders and files for user
  app.get("/api/trash", authenticateUser, (req: any, res) => {
    try {
      const files = db.prepare("SELECT * FROM files WHERE user_id = ? AND is_trashed = 1 ORDER BY created_at DESC").all(req.user.id);
      const folders = db.prepare("SELECT * FROM folders WHERE user_id = ? AND is_trashed = 1 ORDER BY name ASC").all(req.user.id);
      res.json({ files, folders });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Restore file or folder from trash
  app.post("/api/trash/restore", authenticateUser, (req: any, res) => {
    try {
      const { type, id } = req.body;
      if (!type || !id) {
        return res.status(400).json({ error: "Missing type or id" });
      }
      if (type === "file") {
        db.prepare("UPDATE files SET is_trashed = 0 WHERE id = ? AND user_id = ?").run(id, req.user.id);

        // 更新元数据索引文件（标记为已恢复）
        const restoredFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id);
        if (restoredFile) {
          writeMetadataFile(restoredFile);
        }
      } else {
        restoreFolderRecursive(id, req.user.id);

        // 更新文件夹内所有文件的元数据索引
        const filesInFolder = db.prepare("SELECT * FROM files WHERE folder_id = ? AND user_id = ?").all(id, req.user.id) as any[];
        for (const file of filesInFolder) {
          writeMetadataFile(file);
        }
      }
      res.json({ success: true, message: "恢复成功！" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Permanently delete file or folder from trash
  app.post("/api/trash/delete", authenticateUser, (req: any, res) => {
    try {
      const { type, id } = req.body;
      if (!type || !id) {
        return res.status(400).json({ error: "Missing type or id" });
      }
      if (type === "file") {
        const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;
        if (file) {
          // 只删除数据库记录，保留物理文件（内容寻址去重依赖引用计数）
          db.prepare("DELETE FROM files WHERE id = ? AND user_id = ?").run(id, req.user.id);
        }
      } else {
        // 递归删除文件夹及其下的文件记录，但不删除物理文件
        const deleteFolderRecursiveNoPhysical = (folderId: string, userId: string) => {
          const files = db.prepare("SELECT * FROM files WHERE folder_id = ? AND user_id = ?").all(folderId, userId) as any[];
          for (const file of files) {
            db.prepare("DELETE FROM files WHERE id = ? AND user_id = ?").run(file.id, userId);
          }
          const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ? AND user_id = ?").all(folderId, userId) as any[];
          for (const sub of subfolders) {
            deleteFolderRecursiveNoPhysical(sub.id, userId);
          }
          db.prepare("DELETE FROM folders WHERE id = ? AND user_id = ?").run(folderId, userId);
        };
        deleteFolderRecursiveNoPhysical(id, req.user.id);
      }
      res.json({ success: true, message: "已永久删除（仅记录，物理文件保留）！" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Empty all items in recycle bin
  app.post("/api/trash/empty", authenticateUser, (req: any, res) => {
    try {
      // 1. 删除所有回收站中的文件记录（仅数据库，保留物理文件）
      const trashedFiles = db.prepare("SELECT * FROM files WHERE user_id = ? AND is_trashed = 1").all(req.user.id) as any[];
      for (const file of trashedFiles) {
        db.prepare("DELETE FROM files WHERE id = ? AND user_id = ?").run(file.id, req.user.id);
      }

      // 2. 删除所有回收站中的文件夹记录（递归，仅数据库）
      const trashedFolders = db.prepare("SELECT * FROM folders WHERE user_id = ? AND is_trashed = 1").all(req.user.id) as any[];
      const deleteFolderRecursiveNoPhysical = (folderId: string, userId: string) => {
        const files = db.prepare("SELECT * FROM files WHERE folder_id = ? AND user_id = ?").all(folderId, userId) as any[];
        for (const file of files) {
          db.prepare("DELETE FROM files WHERE id = ? AND user_id = ?").run(file.id, userId);
        }
        const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ? AND user_id = ?").all(folderId, userId) as any[];
        for (const sub of subfolders) {
          deleteFolderRecursiveNoPhysical(sub.id, userId);
        }
        db.prepare("DELETE FROM folders WHERE id = ? AND user_id = ?").run(folderId, userId);
      };
      for (const folder of trashedFolders) {
        deleteFolderRecursiveNoPhysical(folder.id, req.user.id);
      }

      res.json({ success: true, message: "回收站已清空（仅记录，物理文件保留）！" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get ALL non-trashed folders for move/copy selector
  app.get("/api/folders/all", authenticateUser, (req: any, res) => {
    try {
      const folders = db.prepare("SELECT * FROM folders WHERE user_id = ? AND (is_trashed IS NULL OR is_trashed = 0) ORDER BY name ASC").all(req.user.id);
      res.json(folders);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Move file to a different folder
  app.post("/api/files/move", authenticateUser, (req: any, res) => {
    try {
      const { fileId, targetFolderId } = req.body;
      if (!fileId) return res.status(400).json({ error: "Missing fileId" });
      const target = targetFolderId || "";

      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(fileId, req.user.id) as any;
      if (!file) return res.status(404).json({ error: "File not found" });

      db.prepare("UPDATE files SET folder_id = ? WHERE id = ? AND user_id = ?").run(target, fileId, req.user.id);

      // 更新元数据索引文件
      const updatedFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(fileId, req.user.id);
      writeMetadataFile(updatedFile);

      res.json({ success: true, message: "移动成功！" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Copy file to folder
  app.post("/api/files/copy", authenticateUser, (req: any, res) => {
    try {
      const { fileId, targetFolderId } = req.body;
      if (!fileId) return res.status(400).json({ error: "Missing fileId" });
      const target = targetFolderId || "";

      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(fileId, req.user.id) as any;
      if (!file) return res.status(404).json({ error: "File not found" });

      if (!fs.existsSync(getFullPath(file.path))) {
        return res.status(404).json({ error: "Physical file missing on server" });
      }

      const newFileId = crypto.randomBytes(16).toString("hex");
      const uniqueId = crypto.randomBytes(12).toString("hex");
      const ext = path.extname(file.name);
      const newFilename = `${uniqueId}${ext}`;
      const newPath = path.join(uploadDir, newFilename);

      fs.copyFileSync(getFullPath(file.path), newPath);

      let newName = file.name;
      if (file.folder_id === target) {
        const extIdx = file.name.lastIndexOf(".");
        if (extIdx !== -1) {
          newName = file.name.substring(0, extIdx) + " - 副本" + file.name.substring(extIdx);
        } else {
          newName = file.name + " - 副本";
        }
      }

      const now = new Date().toISOString();
      const thumbnailPath = file.mime_type.startsWith("image/") ? `/api/files/thumbnail/${newFileId}` : "";

      db.prepare(`
        INSERT INTO files (id, name, original_name, mime_type, size, path, thumbnail_path, created_at, folder_id, is_favorite, tags, user_id, is_trashed)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, '', ?, 0)
      `).run(
        newFileId,
        newName,
        newName,
        file.mime_type,
        file.size,
        toRelativePath(newPath),
        thumbnailPath,
        now,
        target,
        req.user.id
      );

      // 写入元数据索引文件
      const newFile = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(newFileId, req.user.id);
      writeMetadataFile(newFile);

      res.json({ success: true, message: "复制成功！" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // API: SHARED LINKS - PikPak分享链接索引
  // ==========================================

  // GET: Get list of shared links with pagination and search
  app.get("/api/share-links", authenticateUser, (req: any, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;
      const search = (req.query.search as string) || "";

      let query = "SELECT * FROM shared_links WHERE user_id = ?";
      const params: any[] = [req.user.id];

      // Search by name or share_url
      if (search) {
        query += " AND (name LIKE ? OR share_url LIKE ?)";
        params.push(`%${search}%`, `%${search}%`);
      }

      query += " ORDER BY created_at DESC";

      // Get total count for pagination
      const countQuery = `SELECT COUNT(*) as count FROM (${query})`;
      const countStmt = db.prepare(countQuery);
      const totalRow = countStmt.get(...params) as { count: number };
      const total = totalRow ? totalRow.count : 0;

      // Add LIMIT and OFFSET for pagination
      const offset = (page - 1) * limit;
      query += " LIMIT ? OFFSET ?";
      const paginatedParams = [...params, limit, offset];

      const stmt = db.prepare(query);
      const links = stmt.all(...paginatedParams);

      res.json({
        links,
        total,
        page,
        limit,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST: Create a new shared link index
  app.post("/api/share-links", authenticateUser, (req: any, res) => {
    try {
      const { name, shareUrl, size, format } = req.body;
      
      if (!shareUrl || shareUrl.trim() === "") {
        return res.status(400).json({ error: "分享链接不能为空" });
      }

      const id = crypto.randomBytes(16).toString("hex");
      const createdAt = new Date().toISOString();
      
      // Extract pikpak_id from share URL
      let pikpakId = "";
      const urlMatch = shareUrl.match(/\/s\/([a-zA-Z0-9]+)/);
      if (urlMatch) {
        pikpakId = urlMatch[1];
      } else {
        // Try to extract from other URL formats
        const altMatch = shareUrl.match(/[?&]id=([a-zA-Z0-9]+)/);
        if (altMatch) {
          pikpakId = altMatch[1];
        } else {
          pikpakId = crypto.randomBytes(8).toString("hex");
        }
      }

      const stmt = db.prepare(`
        INSERT INTO shared_links (id, name, share_url, pikpak_id, size, format, created_at, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run(
        id,
        name?.trim() || "未命名",
        shareUrl.trim(),
        pikpakId,
        size || 0,
        format || "",
        createdAt,
        req.user.id
      );

      const newLink = db.prepare("SELECT * FROM shared_links WHERE id = ?").get(id);
      res.status(201).json(newLink);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE: Delete a shared link index
  app.delete("/api/share-links/:id", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const result = db.prepare("DELETE FROM shared_links WHERE id = ? AND user_id = ?").run(id, req.user.id);

      if (result.changes === 0) {
        return res.status(404).json({ error: "分享链接不存在" });
      }

      res.json({ success: true, message: "删除成功" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET: Redirect to original PikPak share link
  app.get("/api/share-links/:id/redirect", authenticateUser, (req: any, res) => {
    try {
      const { id } = req.params;
      const link = db.prepare("SELECT * FROM shared_links WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;

      if (!link) {
        return res.status(404).json({ error: "分享链接不存在" });
      }

      // Redirect (status 302) to the original share URL
      res.redirect(302, link.share_url);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST: Parse PikPak share link and return file tree (metadata only, no download)
  app.post("/api/share-links/parse", authenticateUser, async (req: any, res) => {
    try {
      const { shareUrl, passCode } = req.body;
      
      if (!shareUrl || shareUrl.trim() === "") {
        return res.status(400).json({ error: "分享链接不能为空" });
      }

      // Extract share_id from URL
      const urlMatch = shareUrl.match(/\/s\/([a-zA-Z0-9]+)/);
      if (!urlMatch) {
        return res.status(400).json({ error: "无效的分享链接格式" });
      }
      
      const shareId = urlMatch[1];
      
      // PikPak API constants (from OpenList)
      const WebClientID = "YUMx5nI8ZU8Ap8pm";
      const WebClientSecret = "dbw2OtmVEeuUvIptb1Coyg";
      const WebClientVersion = "2.0.0";
      const WebPackageName = "mypikpak.com";
      const WebAlgorithms = [
        "C9qPpZLN8ucRTaTiUMWYS9cQvWOE",
        "+r6CQVxjzJV6LCV",
        "F",
        "pFJRC",
        "9WXYIDGrwTCz2OiVlgZa90qpECPD6olt",
        "/750aCr4lm/Sly/c",
        "RB+DT/gZCrbV",
        "",
        "CyLsf7hdkIRxRm215hl",
        "7xHvLi2tOYP0Y92b",
        "ZGTXXxu8E/MIWaEDB+Sm/",
        "1UI3",
        "E7fP5Pfijd+7K+t6Tg/NhuLq0eEUVChpJSkrKxpO",
        "ihtqpG6FMt65+Xk+tWUH2",
        "NhXXU9rg4XXdzo7u5o",
      ];

      const deviceId = crypto.randomBytes(16).toString('hex');
      
      // Build captcha sign
      const timestamp = Date.now().toString();
      let signStr = WebClientID + WebClientVersion + WebPackageName + deviceId + timestamp;
      for (const alg of WebAlgorithms) {
        signStr = crypto.createHash('md5').update(signStr + alg).digest('hex');
      }
      const captchaSign = "1." + signStr;

      // Step 1: Get captcha token
      const axios = require('axios');
      const captchaResp = await axios.post("https://user.mypikpak.net/v1/shield/captcha/init", {
        action: "GET:/drive/v1/share/detail",
        captcha_token: "",
        client_id: WebClientID,
        device_id: deviceId,
        meta: {
          client_version: WebClientVersion,
          package_name: WebPackageName,
          timestamp: timestamp,
          captcha_sign: captchaSign,
        }
      }, {
        headers: { "Content-Type": "application/json" }
      });

      const captchaToken = captchaResp.data.captcha_token;
      if (!captchaToken) {
        throw new Error("无法获取验证码Token");
      }

      // Step 2: Get share detail (file list)
      let allFiles: any[] = [];
      let totalSize = 0;
      let pageToken = "";
      let hasPassCode = false;

      do {
        const resp = await axios.get("https://api-drive.mypikpak.net/drive/v1/share/detail", {
          params: {
            share_id: shareId,
            parent_id: "",
            limit: 100,
            page_token: pageToken,
            pass_code_token: "",
            with_audit: "true",
            thumbnail_size: "SIZE_LARGE",
          },
          headers: {
            "X-Client-ID": WebClientID,
            "X-Device-ID": deviceId,
            "X-Captcha-Token": captchaToken,
          }
        });

        const data = resp.data;
        if (data.share_status === "PASS_CODE_EMPTY" || data.share_status === "PASS_CODE_ERROR") {
          hasPassCode = true;
          break;
        }
        if (data.share_status !== "OK") {
          throw new Error(data.share_status_text || "分享状态异常");
        }

        if (data.files) {
          for (const file of data.files) {
            allFiles.push(file);
            if (!file.kind?.includes("folder")) {
              totalSize += parseInt(file.size || 0);
            }
          }
        }
        pageToken = data.next_page_token || "";
      } while (pageToken && allFiles.length < 10000);

      // Build tree structure
      const fileMap = new Map(allFiles.map((f: any) => [f.id, { ...f, children: [] }]));
      const roots: any[] = [];
      for (const file of allFiles) {
        const node = fileMap.get(file.id)!;
        if (file.parent_id && fileMap.has(file.parent_id)) {
          fileMap.get(file.parent_id)!.children.push(node);
        } else {
          roots.push(node);
        }
      }

      res.json({
        shareId,
        hasPassCode,
        files: roots,
        totalSize,
        fileCount: allFiles.filter(f => !f.kind?.includes("folder")).length,
        folderCount: allFiles.filter(f => f.kind?.includes("folder")).length,
      });
    } catch (err: any) {
      console.error("Parse share link error:", err.response?.data || err.message);
      res.status(500).json({ error: err.response?.data?.error_description || err.message || "解析失败" });
    }
  });


  // ==========================================
  // VITE & STATIC FILES SERVING
  // ==========================================
  app.get("/api/files/thumbnail/:id", authenticateUser, async (req: any, res) => {
    try {
      const { id } = req.params;
      const file = db.prepare("SELECT * FROM files WHERE id = ? AND user_id = ?").get(id, req.user.id) as any;
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      if (!fs.existsSync(getFullPath(file.path))) {
        return res.status(404).json({ error: "Physical file missing on server" });
      }

      const thumbsDir = path.join(uploadDir, "thumbnails");
      if (!fs.existsSync(thumbsDir)) {
        fs.mkdirSync(thumbsDir, { recursive: true });
      }
      const thumbPath = path.join(thumbsDir, `${file.id}.webp`);

      // If already cached, serve it
      if (fs.existsSync(thumbPath)) {
        res.setHeader("Content-Type", "image/webp");
        res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
        return res.sendFile(thumbPath);
      }

      // Generate thumbnail for images
      if (file.mime_type.startsWith("image/")) {
        try {
          await sharp(getFullPath(file.path))
            .resize({ width: 400, withoutEnlargement: true })
            .webp({ quality: 75 })
            .toFile(thumbPath);

          res.setHeader("Content-Type", "image/webp");
          res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
          return res.sendFile(thumbPath);
        } catch (sharpErr) {
          console.error("Error generating image thumbnail:", sharpErr);
          // Fallback to original
          res.setHeader("Content-Type", file.mime_type);
          return res.sendFile(getFullPath(file.path));
        }
      }

      // Generate thumbnail for videos using ffmpeg
      if (file.mime_type.startsWith("video/")) {
        try {
          const { execSync } = require("child_process");
          // Use ffmpeg to extract first frame as thumbnail
          execSync(`ffmpeg -i "${getFullPath(file.path)}" -ss 00:00:01 -vframes 1 -vf "scale=400:-1" -q:v 2 -y "${thumbPath}"`, {
            timeout: 10000,
            stdio: "ignore"
          });

          if (fs.existsSync(thumbPath)) {
            res.setHeader("Content-Type", "image/webp");
            res.setHeader("Cache-Control", "public, max-age=2592000, immutable");
            return res.sendFile(thumbPath);
          }
        } catch (ffmpegErr) {
          console.error("Error generating video thumbnail:", ffmpegErr);
        }
      }

      // Fallback: return original file for non-image/video
      res.setHeader("Content-Type", file.mime_type);
      return res.sendFile(getFullPath(file.path));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // ==========================================
  // VITE & STATIC FILES SERVING
  // ==========================================

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    
    // 静态资源缓存策略：带哈希的资源长期缓存，HTML 不缓存
    app.use(express.static(distPath, {
      setHeaders: (res, filePath) => {
        // HTML 文件不缓存
        if (filePath.endsWith(".html")) {
          res.setHeader("Cache-Control", "no-cache");
        } else {
          // 其他静态资源（JS、CSS、图片等）长期缓存 1 年
          // Vite 构建的文件名包含哈希，内容变化时文件名会变
          res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        }
      }
    }));
    
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"), {
        headers: { "Cache-Control": "no-cache" }
      });
    });
  }

  // Create HTTP server
  const server = http.createServer(app);

  // ==========================================
  // WEBSOCKET: 实时系统信息
  // ==========================================
  const wss = new WebSocketServer({ server, path: "/ws/system" });

  // 采集系统信息
  function getSystemInfo() {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsage = (usedMem / totalMem) * 100;

    const cpus = os.cpus();
    const cpuCount = cpus.length;
    
    // 计算 CPU 使用率（简单方式）
    let totalIdle = 0;
    let totalTick = 0;
    for (const cpu of cpus) {
      for (const type in cpu.times) {
        totalTick += cpu.times[type as keyof typeof cpu.times];
      }
      totalIdle += cpu.times.idle;
    }
    const cpuUsage = (1 - totalIdle / totalTick) * 100;

    const loadAvg = os.loadavg();
    const uptimeSeconds = Math.floor((Date.now() - serverStartTime) / 1000);
    
    // 格式化运行时间
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    let uptimeFormatted = "";
    if (days > 0) uptimeFormatted += `${days}天`;
    if (hours > 0) uptimeFormatted += `${hours}小时`;
    if (minutes > 0) uptimeFormatted += `${minutes}分钟`;
    if (uptimeFormatted === "") uptimeFormatted = `${seconds}秒`;

    // 磁盘信息（获取上传目录所在磁盘）
    let diskTotal = 0;
    let diskUsed = 0;
    let diskFree = 0;
    try {
      const stats = fs.statfsSync(uploadDir);
      diskTotal = stats.blocks * stats.bsize;
      diskFree = stats.bfree * stats.bsize;
      diskUsed = diskTotal - diskFree;
    } catch (e) {
      // ignore
    }
    const diskUsage = diskTotal > 0 ? (diskUsed / diskTotal) * 100 : 0;

    // 网络信息（简单方式，读取 /proc/net/dev）
    let netRx = 0;
    let netTx = 0;
    try {
      const netDev = fs.readFileSync("/proc/net/dev", "utf8");
      const lines = netDev.split("\n");
      for (const line of lines.slice(2)) {
        const parts = line.trim().split(/\s+/);
        if (parts.length >= 10 && parts[0] !== "lo:") {
          netRx += parseInt(parts[1]) || 0;
          netTx += parseInt(parts[9]) || 0;
        }
      }
    } catch (e) {
      // ignore
    }

    return {
      timestamp: Date.now(),
      cpu: {
        usage: cpuUsage.toFixed(1),
        cores: cpuCount,
        loadAvg: loadAvg.map(l => l.toFixed(2)),
      },
      memory: {
        total: totalMem,
        used: usedMem,
        free: freeMem,
        usage: memUsage.toFixed(1),
      },
      disk: {
        total: diskTotal,
        used: diskUsed,
        free: diskFree,
        usage: diskUsage.toFixed(1),
      },
      network: {
        rx: netRx,
        tx: netTx,
      },
      system: {
        platform: os.platform(),
        arch: os.arch(),
        hostname: os.hostname(),
        uptime: uptimeSeconds,
        uptimeFormatted: uptimeFormatted,
      },
    };
  }

  // 广播系统信息给所有连接的客户端
  function broadcastSystemInfo() {
    const info = getSystemInfo();
    const data = JSON.stringify({ type: "system-info", data: info });
    
    wss.clients.forEach((client) => {
      if (client.readyState === 1) { // OPEN
        client.send(data);
      }
    });
  }

  // 每 20 秒推送一次系统信息
  setInterval(broadcastSystemInfo, 20000);

  wss.on("connection", (ws) => {
    console.log("WebSocket client connected for system info");
    
    // 连接后立即发送一次
    const info = getSystemInfo();
    ws.send(JSON.stringify({ type: "system-info", data: info }));

    // Ping 心跳机制（20秒间隔）
    const pingInterval = setInterval(() => {
      if (ws.readyState === 1) { // OPEN
        ws.ping();
      }
    }, 20000);

    ws.on("pong", () => {
      // 收到客户端 pong 响应，连接正常
    });

    ws.on("close", () => {
      console.log("WebSocket client disconnected");
      clearInterval(pingInterval);
    });

    ws.on("error", (err) => {
      console.error("WebSocket error:", err);
      clearInterval(pingInterval);
    });
  });

  server.listen(PORT, "::", () => {
    console.log(`Server running on http://[::]:${PORT} (IPv4+IPv6 dual stack)`);
    console.log(`WebSocket available at ws://[::]:${PORT}/ws/system`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server", err);
});
