const Database = require('better-sqlite3');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const dbPath = '/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/UserStorage/personal-cloud-drive/db/drive.db';
const uploadDir = '/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/UserStorage/personal-cloud-drive/uploads';

const db = new Database(dbPath);

// 获取所有没有 content_hash 的文件
const files = db.prepare("SELECT id, path, name, size FROM files WHERE content_hash IS NULL OR content_hash = ''").all();
console.log(`需要回填的文件数: ${files.length}`);

let updated = 0;
let skipped = 0;
let errors = 0;

for (const file of files) {
  const fullPath = path.join(uploadDir, file.path);
  if (!fs.existsSync(fullPath)) {
    console.log(`[跳过] 文件不存在: ${file.name} (${file.path})`);
    skipped++;
    continue;
  }
  
  try {
    const buffer = fs.readFileSync(fullPath);
    const hash = crypto.createHash('sha256').update(buffer).digest('hex');
    
    // 更新 files 表
    db.prepare("UPDATE files SET content_hash = ? WHERE id = ?").run(hash, file.id);
    
    // 更新/插入 file_contents 表
    const existing = db.prepare("SELECT * FROM file_contents WHERE content_hash = ?").get(hash);
    if (existing) {
      db.prepare("UPDATE file_contents SET ref_count = ref_count + 1 WHERE content_hash = ?").run(hash);
      console.log(`[去重] ${file.name}: 发现相同内容，引用计数+1 (hash: ${hash.substring(0,16)}...)`);
    } else {
      db.prepare(`
        INSERT INTO file_contents (content_hash, path, size, ref_count, created_at, original_name)
        VALUES (?, ?, ?, 1, ?, ?)
      `).run(hash, file.path, file.size, new Date().toISOString(), file.name);
    }
    
    updated++;
    if (updated % 10 === 0) console.log(`进度: ${updated}/${files.length}`);
  } catch (e) {
    console.error(`[错误] ${file.name}: ${e.message}`);
    errors++;
  }
}

console.log(`完成: 更新 ${updated}, 跳过 ${skipped}, 错误 ${errors}`);

// 显示去重统计
const stats = db.prepare("SELECT content_hash, COUNT(*) as cnt, SUM(size) as total_size FROM files WHERE content_hash IS NOT NULL GROUP BY content_hash HAVING cnt > 1").all();
if (stats.length > 0) {
  console.log("\n发现重复内容:");
  for (const s of stats) {
    console.log(`  Hash ${s.content_hash.substring(0,16)}...: ${s.cnt} 个文件, 总大小 ${(s.total_size/1024/1024).toFixed(2)} MB`);
  }
} else {
  console.log("\n暂无重复内容文件");
}