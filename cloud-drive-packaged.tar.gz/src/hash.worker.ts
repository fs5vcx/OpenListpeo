// Web Worker: 使用 hash-wasm 计算 SHA256（与后端一致）
import { sha256 } from 'hash-wasm';

interface HashWorkerMessage {
  file: File;
}

interface ProgressMessage {
  type: 'progress';
  percent: number;
}

interface ResultMessage {
  type: 'result';
  hash: string;
}

interface ErrorMessage {
  type: 'error';
  error: string;
}

self.onmessage = async (e: MessageEvent<HashWorkerMessage>) => {
  const { file } = e.data;
  
  try {
    // 读取整个文件
    const arrayBuffer = await file.arrayBuffer();
    
    // 使用 hash-wasm 计算 SHA256
    const hash = await sha256(new Uint8Array(arrayBuffer));
    
    self.postMessage({ type: 'progress', percent: 100 } as ProgressMessage);
    self.postMessage({ type: 'result', hash } as ResultMessage);
    
  } catch (error: any) {
    self.postMessage({ type: 'error', error: error.message } as ErrorMessage);
  }
};

export {};
