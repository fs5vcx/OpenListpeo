import React, { useState, useEffect, useRef } from "react";
import { 
  Folder, 
  FolderPlus, 
  File, 
  FileText, 
  Image as ImageIcon, 
  Video as VideoIcon, 
  Music as MusicIcon, 
  Search, 
  Upload, 
  Download, 
  Trash2, 
  Edit3, 
  Star, 
  ChevronRight, 
  Grid, 
  List,
  Menu, 
  ArrowUpDown, 
  Plus, 
  HardDrive, 
  X, 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  RotateCcw,
  Play, 
  Pause, 
  Volume2, 
  ExternalLink, 
  FileCode,
  ArrowUp,
  FolderOpen,
  Info,
  Calendar,
  AlertCircle,
  Maximize2,
  Minimize2,
  LogOut,
  Copy,
  FolderInput,
  Link2,
  Share2,
  PlusCircle,
  Settings
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Folder as FolderType, DriveFile, DriveStats } from "./types";
import HashWorker from "./hash.worker?worker";

// ==========================================
// UTILITY FUNCTIONS (Module level)
// ==========================================

const formatBytes = (bytes: number, decimals = 2): string => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + " " + sizes[i];
};

const formatDate = (isoString: string): string => {
  try {
    return new Date(isoString).toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return isoString;
  }
};

// Shared Link Form Component
const SharedLinkForm: React.FC<{ onSuccess: () => void }> = ({ onSuccess }) => {
  const [name, setName] = useState("");
  const [shareUrl, setShareUrl] = useState("");
  const [size, setSize] = useState("");
  const [format, setFormat] = useState("");
  const [loading, setLoading] = useState(false);
  const [parseLoading, setParseLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/share-links", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("auth_token") || ""}`,
        },
        body: JSON.stringify({
          name: name.trim() || "未命名",
          shareUrl: shareUrl.trim(),
          size: parseInt(size) || 0,
          format: format.trim(),
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "创建失败");
      }

      setName("");
      setShareUrl("");
      setSize("");
      setFormat("");
      onSuccess();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Auto-fetch share metadata by parsing PikPak page
  const handleParseShare = async () => {
    if (!shareUrl.trim()) {
      setError("请先输入分享链接");
      return;
    }
    
    setParseLoading(true);
    setError("");
    
    try {
      // Extract share_id
      const urlMatch = shareUrl.match(/\/s\/([a-zA-Z0-9]+)/);
      if (!urlMatch) throw new Error("无法解析分享链接");
      
      // Call backend proxy to fetch share info
      const res = await fetch("/api/share-links/parse", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("auth_token") || ""}`,
        },
        body: JSON.stringify({ shareUrl }),
      });
      
      const data = await res.json();
      if (data.instruction) {
        // Frontend should directly fetch via browser
        // For now, just extract name if available
        if (!name.trim()) {
          setName(`PikPak 分享 (${urlMatch[1]})`);
        }
        alert("PikPak 分享解析需要浏览器直连。请手动填写信息或稍后在浏览器环境中实现。");
      }
    } catch (err: any) {
      setError(err.message || "解析失败");
    } finally {
      setParseLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="text-xs text-zinc-400 mb-1 block">分享链接 <span className="text-rose-400">*</span></label>
        <div className="flex gap-2">
          <input
            type="url"
            value={shareUrl}
            onChange={(e) => setShareUrl(e.target.value)}
            placeholder="https://mypikpak.com/s/..."
            required
            className="flex-1 px-3 py-2 bg-[#18181b] border border-[#27272a] rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] placeholder:text-zinc-500"
          />
          <button
            type="button"
            onClick={handleParseShare}
            disabled={parseLoading || !shareUrl.trim()}
            className="px-3 py-2 bg-sky-600 hover:bg-sky-700 disabled:bg-sky-950/30 text-white text-xs rounded-lg transition-colors"
            title="自动抓取分享信息"
          >
            {parseLoading ? "..." : "抓取"}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-zinc-400 mb-1 block">名称（可选）</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="留空自动从链接提取"
            className="w-full px-3 py-2 bg-[#18181b] border border-[#27272a] rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] placeholder:text-zinc-500"
          />
        </div>
        <div>
          <label className="text-xs text-zinc-400 mb-1 block">大小（字节，可选）</label>
          <input
            type="number"
            value={size}
            onChange={(e) => setSize(e.target.value)}
            placeholder="0"
            className="w-full px-3 py-2 bg-[#18181b] border border-[#27272a] rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] placeholder:text-zinc-500"
          />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-xs text-zinc-400 mb-1 block">格式（可选）</label>
          <input
            type="text"
            value={format}
            onChange={(e) => setFormat(e.target.value)}
            placeholder="video/mp4, image/png 等"
            className="w-full px-3 py-2 bg-[#18181b] border border-[#27272a] rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] placeholder:text-zinc-500"
          />
        </div>
        <div></div>
      </div>
      {error && <p className="text-xs text-rose-400">{error}</p>}
      <button
        type="submit"
        disabled={loading || !shareUrl.trim()}
        className="w-full py-2.5 bg-sky-600 hover:bg-sky-700 disabled:bg-sky-950/30 disabled:hover:bg-sky-950/30 text-white font-semibold text-sm rounded-xl transition-all cursor-pointer disabled:cursor-not-allowed"
      >
        {loading ? "创建中..." : "创建索引"}
      </button>
    </form>
  );
};

// Shared Link Card Component
const SharedLinkCard: React.FC<{ 
  link: { 
    id: string; 
    name: string; 
    share_url: string; 
    pikpak_id: string; 
    size: number; 
    format: string; 
    created_at: string; 
  };
  onDelete: (id: string) => void;
}> = ({ link, onDelete }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="group bg-[#18181b] border border-[#27272a] rounded-xl p-4 hover:border-sky-500/30 transition-colors"
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-sky-500/15 flex items-center justify-center">
          <ExternalLink className="w-5 h-5 text-sky-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-white truncate">{link.name || "未命名"}</h3>
            <button
              onClick={() => onDelete(link.id)}
              className="flex-shrink-0 p-1.5 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
              title="删除"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-zinc-500 mt-1 truncate">{link.share_url}</p>
          <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-zinc-400">
            {link.size > 0 && <span className="flex items-center gap-1"><FileCode className="w-3 h-3" /> {formatBytes(link.size)}</span>}
            {link.format && <span className="px-2 py-0.5 bg-zinc-800 rounded text-zinc-300">{link.format}</span>}
            {link.pikpak_id && <span className="px-2 py-0.5 bg-zinc-800 rounded text-zinc-300 font-mono text-[10px]">{link.pikpak_id}</span>}
            <span>{formatDate(link.created_at)}</span>
          </div>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-[#27272a] flex justify-end">
        <a
          href={link.share_url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-sm text-sky-400 hover:text-sky-300 font-medium transition-colors"
        >
          <ExternalLink className="w-4 h-4" />
          打开链接
        </a>
      </div>
    </motion.div>
  );
};

export default function App() {
  // Authentication states
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<{ id: string; username: string } | null>(null);
  const [hasUsers, setHasUsers] = useState<boolean>(true);
  const [authToken, setAuthToken] = useState<string>("");
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Auth form states
  const [authUsername, setAuthUsername] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthSubmitting, setIsAuthSubmitting] = useState(false);

  // Navigation & Folder structure
  const [currentFolderId, setCurrentFolderId] = useState<string>("");
  const [folders, setFolders] = useState<FolderType[]>([]);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [breadcrumbs, setBreadcrumbs] = useState<{ id: string; name: string }[]>([]);
  
  // Tabs & Filtering
  const [activeTab, setActiveTab] = useState<string>("all"); // all, photos-videos, favorites, folders
  const [fileTypeFilter, setFileTypeFilter] = useState<string>("all"); // all, images, videos, audio, documents, others
  const [searchInput, setSearchInput] = useState<string>(""); // 搜索输入框实时值
  const [searchQuery, setSearchQuery] = useState<string>(""); // 防抖后的搜索值
  const [sortField, setSortField] = useState<"name" | "size" | "created_at">("created_at");
  const [sortOrder, setSortOrder] = useState<"ASC" | "DESC">("DESC");
  
  // Statistics
  const [stats, setStats] = useState<DriveStats | null>(null);
  
  // UI Status
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadSpeed, setUploadSpeed] = useState<string>("0 KB/s");
  const [uploadingFileName, setUploadingFileName] = useState<string>("");
  const [isUploadPaused, setIsUploadPaused] = useState<boolean>(false);
  const [uploadCancelRequested, setUploadCancelRequested] = useState<boolean>(false);
  const isUploadPausedRef = useRef<boolean>(false);
  const uploadCancelRequestedRef = useRef<boolean>(false);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [page, setPage] = useState<number>(1);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const [isFetchingContents, setIsFetchingContents] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);

  // Settings - Chunk Size (可配置分片大小)
  const [chunkSize, setChunkSize] = useState<number>(() => {
    const saved = localStorage.getItem("upload_chunk_size_mb");
    return saved ? parseInt(saved, 10) : 30;
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Mobile Menu State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // 实时系统信息状态
  const [systemInfo, setSystemInfo] = useState<any>(null);
  const [wsConnected, setWsConnected] = useState<boolean>(false);

  // Shared Links State
  const [sharedLinks, setSharedLinks] = useState<any[]>([]);
  const [sharedLinksLoading, setSharedLinksLoading] = useState(false);
  const [sharedLinksPage, setSharedLinksPage] = useState(1);
  const [sharedLinksTotal, setSharedLinksTotal] = useState(0);
  const [sharedLinksSearch, setSharedLinksSearch] = useState("");
  const sharedLinksLimit = 50;

  // Modal States
  const [isNewFolderOpen, setIsNewFolderOpen] = useState<boolean>(false);
  const [newFolderName, setNewFolderName] = useState<string>("");
  
  const [renameTargetFile, setRenameTargetFile] = useState<DriveFile | null>(null);
  const [renameTargetFolder, setRenameTargetFolder] = useState<FolderType | null>(null);
  const [renameInputName, setRenameInputName] = useState<string>("");

  // Move / Copy states
  const [isMoveCopyOpen, setIsMoveCopyOpen] = useState<boolean>(false);
  const [moveCopyType, setMoveCopyType] = useState<"move" | "copy">("move");
  const [moveCopyTargetFile, setMoveCopyTargetFile] = useState<DriveFile | null>(null);
  const [moveCopySelectedFolderId, setMoveCopySelectedFolderId] = useState<string>("");
  const [allFoldersList, setAllFoldersList] = useState<FolderType[]>([]);

  const [previewFile, setPreviewFile] = useState<DriveFile | null>(null);
  const [previewTextContent, setPreviewTextContent] = useState<string | null>(null);
  const [showPreviewSidebar, setShowPreviewSidebar] = useState<boolean>(false);
  
  // Zooming & dragging states for image preview
  const [imageZoom, setImageZoom] = useState<number>(1);
  const [imageRotation, setImageRotation] = useState<number>(0);
  const [isImageFullscreen, setIsImageFullscreen] = useState<boolean>(false);
  const [imageOffset, setImageOffset] = useState({ x: 0, y: 0 });
  const [isDraggingImage, setIsDraggingImage] = useState(false);
  const [imageDragStart, setImageDragStart] = useState({ x: 0, y: 0 });

  // Touch zoom helpers
  const touchStartDistRef = useRef<number | null>(null);
  const touchStartZoomRef = useRef<number>(1);

  // References
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const imgContainerRef = useRef<HTMLDivElement>(null);

  // 搜索：按回车键执行搜索，不实时搜索节省资源
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      setSearchQuery(searchInput);
    }
  };

  // customFetch wrapper to include Bearer Authorization token automatically
  const customFetch = async (url: string, options: RequestInit = {}) => {
    const headers = {
      ...options.headers,
    } as Record<string, string>;

    const token = authToken || localStorage.getItem("auth_token");
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (response.status === 401 && isAuthenticated) {
      setIsAuthenticated(false);
      setCurrentUser(null);
      setAuthToken("");
      localStorage.removeItem("auth_token");
      setErrorMessage("登录状态已过期，请重新登录");
    }

    return response;
  };

  // Check current auth status on mount
  const checkAuthStatus = async () => {
    try {
      const res = await fetch("/api/auth/status");
      if (res.ok) {
        const data = await res.json();
        setHasUsers(data.hasUsers);
        setIsAuthenticated(data.loggedIn);
        setCurrentUser(data.user);
        if (data.loggedIn) {
          const storedToken = localStorage.getItem("auth_token") || "";
          setAuthToken(storedToken);
        }
      }
    } catch (err) {
      console.error("Auth status check failed:", err);
    } finally {
      setAuthLoading(false);
    }
  };

  useEffect(() => {
    checkAuthStatus();
  }, []);

  // WebSocket 实时系统信息
  useEffect(() => {
    if (!isAuthenticated) return;

    let ws: WebSocket | null = null;
    let reconnectTimer: NodeJS.Timeout | null = null;

    const connectWebSocket = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws/system`;
      
      ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log("WebSocket connected for system info");
        setWsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "system-info") {
            setSystemInfo(data.data);
          }
        } catch (e) {
          console.error("Failed to parse WebSocket message:", e);
        }
      };

      ws.onclose = () => {
        console.log("WebSocket disconnected");
        setWsConnected(false);
        // 自动重连
        reconnectTimer = setTimeout(connectWebSocket, 3000);
      };

      ws.onerror = (err) => {
        console.error("WebSocket error:", err);
        setWsConnected(false);
      };
    };

    connectWebSocket();

    return () => {
      if (ws) {
        ws.close();
      }
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
      }
    };
  }, [isAuthenticated]);

  // Handle Login & Registration Submit
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUsername.trim() || !authPassword.trim()) {
      setAuthError("用户名和密码不能为空");
      return;
    }

    setAuthError(null);
    setIsAuthSubmitting(true);

    try {
      const isRegisteringFirstUser = !hasUsers;
      const isRegisterMode = !hasUsers || authMode === "register";
      const endpoint = isRegisterMode ? "/api/auth/register" : "/api/auth/login";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: authUsername.trim(),
          password: authPassword.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "操作失败");
      }

      if (isRegisterMode) {
        setSuccessMessage(isRegisteringFirstUser ? "管理员账号创建成功，正在为您登录..." : "账号注册成功，请登录");
        
        if (isRegisteringFirstUser) {
          // Automatic login for the first user
          const loginRes = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              username: authUsername.trim(),
              password: authPassword.trim(),
            }),
          });
          const loginData = await loginRes.json();
          if (loginRes.ok) {
            setSuccessMessage("管理员账号初始化成功，欢迎使用！");
            localStorage.setItem("auth_token", loginData.token);
            setAuthToken(loginData.token);
            setCurrentUser(loginData.user);
            setIsAuthenticated(true);
            setHasUsers(true);
          } else {
            // Fallback to login form if auto-login fails for some reason
            setAuthMode("login");
            setAuthPassword("");
            setHasUsers(true);
          }
        } else {
          setAuthMode("login");
          setAuthPassword("");
          setHasUsers(true);
        }
      } else {
        setSuccessMessage("登录成功，欢迎回来！");
        localStorage.setItem("auth_token", data.token);
        setAuthToken(data.token);
        setCurrentUser(data.user);
        setIsAuthenticated(true);
      }
    } catch (err: any) {
      setAuthError(err.message || "连接服务器失败");
    } finally {
      setIsAuthSubmitting(false);
    }
  };

  // Handle Logout
  const handleLogout = async () => {
    if (!confirm("确定要退出登录吗？")) return;
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch (e) {
      console.error(e);
    }
    localStorage.removeItem("auth_token");
    setAuthToken("");
    setIsAuthenticated(false);
    setCurrentUser(null);
    setFolders([]);
    setFiles([]);
    setStats(null);
    setSuccessMessage("您已安全退出登录");
  };

  // Notification Banner Timeout
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Listen for Escape key to exit fullscreen or close preview
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (isImageFullscreen) {
          setIsImageFullscreen(false);
        } else if (previewFile) {
          setPreviewFile(null);
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isImageFullscreen, previewFile]);

  // Reset image fullscreen state when preview file is closed
  useEffect(() => {
    if (!previewFile) {
      setIsImageFullscreen(false);
    }
  }, [previewFile]);

  // Determine dynamic file section title based on active filter / navigation
  const getFileHeaderLabel = () => {
    if (activeTab === "trash") return "回收站";
    if (activeTab === "favorites") return "我的收藏";
    if (activeTab === "photos-videos") return "图片视频";
    if (searchQuery.trim() !== "") return `搜索: ${searchQuery}`;
    
    if (currentFolderId) {
      const currentFolder = breadcrumbs[breadcrumbs.length - 1];
      if (currentFolder) return currentFolder.name;
    }

    if (fileTypeFilter !== "all") {
      const mapping: Record<string, string> = {
        images: "图片",
        videos: "视频",
        audio: "音频",
        documents: "文档",
        others: "其他"
      };
      return mapping[fileTypeFilter] || "文件";
    }

    return "全部文件";
  };

  // Fetch folders and files in current view
  const fetchDriveContents = async () => {
    if (!isAuthenticated) return;
    setIsFetchingContents(true);
    try {
      if (activeTab === "trash") {
        const trashRes = await customFetch(`/api/trash`);
        if (!trashRes.ok) throw new Error("Failed to fetch trash contents");
        const trashData = await trashRes.json();
        setFolders(trashData.folders || []);
        setFiles(trashData.files || []);
        setHasMore(false);
        setPage(1);
        return;
      }

      // Determine folders based on current folder id (skip when searching)
      if (searchQuery.trim() === "") {
        const foldersRes = await customFetch(`/api/folders?parentId=${currentFolderId}`);
        if (!foldersRes.ok) throw new Error("Failed to fetch folders");
        const foldersData = await foldersRes.json();
        setFolders(foldersData);
      }

      // Determine files API URL with query parameters
      let filesUrl = `/api/files?folderId=${currentFolderId}&sortField=${sortField}&sortOrder=${sortOrder}&page=1&limit=12`;
      
      if (activeTab === "favorites") {
        filesUrl = `/api/files?isFavorite=true&sortField=${sortField}&sortOrder=${sortOrder}&page=1&limit=12`;
      } else if (activeTab === "photos-videos") {
        filesUrl = `/api/files?folderId=${currentFolderId}&type=images&sortField=${sortField}&sortOrder=${sortOrder}&page=1&limit=12`;
      } else if (fileTypeFilter !== "all") {
        filesUrl += `&type=${fileTypeFilter}`;
      }

      if (searchQuery.trim() !== "") {
        filesUrl = `/api/files?search=${encodeURIComponent(searchQuery)}&sortField=${sortField}&sortOrder=${sortOrder}&page=1&limit=12`;
      }

      const filesRes = await customFetch(filesUrl);
      if (!filesRes.ok) throw new Error("Failed to fetch files");
      const filesData = await filesRes.json();
      
      setFiles(filesData.files || []);
      setHasMore(filesData.hasMore || false);
      setPage(1);

      // Set search folders when searching
      if (searchQuery.trim() !== "" && filesData.folders) {
        setFolders(filesData.folders);
      }

    } catch (err: any) {
      setErrorMessage(err.message || "Network Error");
    } finally {
      setIsFetchingContents(false);
    }
  };

  // Fetch more files for pagination / infinite scroll
  const loadMoreFiles = async () => {
    if (isLoadingMore || !hasMore || !isAuthenticated || isFetchingContents) return;
    setIsLoadingMore(true);
    try {
      const nextPage = page + 1;
      let filesUrl = `/api/files?folderId=${currentFolderId}&sortField=${sortField}&sortOrder=${sortOrder}&page=${nextPage}&limit=12`;
      
      if (activeTab === "favorites") {
        filesUrl = `/api/files?isFavorite=true&sortField=${sortField}&sortOrder=${sortOrder}&page=${nextPage}&limit=12`;
      } else if (activeTab === "photos-videos") {
        filesUrl = `/api/files?folderId=${currentFolderId}&type=images&sortField=${sortField}&sortOrder=${sortOrder}&page=${nextPage}&limit=12`;
      } else if (fileTypeFilter !== "all") {
        filesUrl += `&type=${fileTypeFilter}`;
      }

      if (searchQuery.trim() !== "") {
        filesUrl = `/api/files?search=${encodeURIComponent(searchQuery)}&sortField=${sortField}&sortOrder=${sortOrder}&page=${nextPage}&limit=12`;
      }

      const filesRes = await customFetch(filesUrl);
      if (!filesRes.ok) throw new Error("Failed to load more files");
      const filesData = await filesRes.json();
      
      setFiles((prev) => [...prev, ...(filesData.files || [])]);
      setHasMore(filesData.hasMore || false);
      setPage(nextPage);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to load more files");
    } finally {
      setIsLoadingMore(false);
    }
  };

  // Clear entire database and uploaded files (system reset)
  const handleSystemReset = async () => {
    if (!confirm("⚠️ 警告：确定要清空所有数据库记录和已上传的文件吗？此操作将永久删除您所有的文件夹及文件，无法恢复。")) return;
    setIsResetting(true);
    try {
      const res = await customFetch("/api/system/reset", {
        method: "POST"
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Reset failed");
      }

      setSuccessMessage("云盘已成功清空，所有文件和目录已重置！");
      setFiles([]);
      setFolders([]);
      setCurrentFolderId("");
      setBreadcrumbs([]);
      setHasMore(false);
      setPage(1);
      
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "清空云盘失败");
    } finally {
      setIsResetting(false);
    }
  };

  // Intersection Observer for Infinite Scroll
  const observerTarget = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore && !isFetchingContents) {
          loadMoreFiles();
        }
      },
      { threshold: 0.1 }
    );

    if (observerTarget.current) {
      observer.observe(observerTarget.current);
    }

    return () => {
      if (observerTarget.current) {
        observer.unobserve(observerTarget.current);
      }
    };
  }, [observerTarget, hasMore, isLoadingMore, isFetchingContents, page, currentFolderId, activeTab, fileTypeFilter, sortField, sortOrder, searchQuery, isAuthenticated]);

  // Fetch Drive Statistics
  const fetchStats = async () => {
    if (!isAuthenticated) return;
    try {
      const res = await customFetch("/api/stats");
      if (!res.ok) throw new Error("Failed to fetch statistics");
      const data = await res.json();
      setStats(data);
    } catch (err: any) {
      console.error("Stats fetching error:", err);
    }
  };

  // Fetch Shared Links
  const fetchSharedLinks = async (page: number = 1, search: string = "") => {
    if (!isAuthenticated) return;
    setSharedLinksLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: sharedLinksLimit.toString(),
      });
      if (search) params.append("search", search);
      
      const res = await customFetch(`/api/share-links?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch shared links");
      const data = await res.json();
      
      if (page === 1) {
        setSharedLinks(data.links || []);
      } else {
        setSharedLinks((prev) => [...prev, ...(data.links || [])]);
      }
      setSharedLinksTotal(data.total || 0);
    } catch (err: any) {
      setErrorMessage(err.message || "获取分享链接失败");
    } finally {
      setSharedLinksLoading(false);
    }
  };

  // Delete shared link
  const handleDeleteSharedLink = async (id: string) => {
    try {
      const res = await customFetch(`/api/share-links/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("删除失败");
      setSharedLinks((prev) => prev.filter((l) => l.id !== id));
      setSharedLinksTotal((prev) => prev - 1);
    } catch (err: any) {
      setErrorMessage(err.message || "删除失败");
    }
  };

  // Run on directory changes
  useEffect(() => {
    if (isAuthenticated) {
      fetchDriveContents();
      fetchStats();
    }
  }, [currentFolderId, activeTab, fileTypeFilter, sortField, sortOrder, searchQuery, isAuthenticated]);

  // Fetch shared links when tab changes to shared-links
  useEffect(() => {
    if (isAuthenticated && activeTab === "shared-links") {
      setSharedLinksPage(1);
      fetchSharedLinks(1, sharedLinksSearch);
    }
  }, [activeTab, isAuthenticated]);

  // Navigate folder helper
  const navigateToFolder = (folderId: string, folderName: string) => {
    // Clear search when navigating
    setSearchQuery("");
    
    if (folderId === "") {
      setCurrentFolderId("");
      setBreadcrumbs([]);
      return;
    }

    // Check if folder is already in breadcrumbs
    const index = breadcrumbs.findIndex(b => b.id === folderId);
    if (index !== -1) {
      // Backtrack to that point
      setBreadcrumbs(breadcrumbs.slice(0, index + 1));
    } else {
      // Append to path
      setBreadcrumbs([...breadcrumbs, { id: folderId, name: folderName }]);
    }
    
    setCurrentFolderId(folderId);
  };

  // Handle Breadcrumb click
  const handleBreadcrumbClick = (id: string, index: number) => {
    setSearchQuery("");
    if (id === "") {
      setCurrentFolderId("");
      setBreadcrumbs([]);
    } else {
      setBreadcrumbs(breadcrumbs.slice(0, index + 1));
      setCurrentFolderId(id);
    }
  };

  // File Upload Logic
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const filesList = event.target.files;
    if (!filesList || filesList.length === 0) return;

    await uploadFilesBatch(Array.from(filesList));
  };

  // 断点续传：分片大小（可配置，默认 30MB）
  const getChunkSize = () => {
    return chunkSize * 1024 * 1024;
  };

  // 计算文件 MD5 哈希（Web Worker + hash-wasm，速度更快）
  const calculateFileHash = (file: File, onProgress?: (percent: number) => void): Promise<string> => {
    return new Promise((resolve, reject) => {
      const worker = new HashWorker();
      
      worker.onmessage = (e) => {
        const { type, percent, hash, error } = e.data;
        
        if (type === 'progress' && onProgress) {
          onProgress(percent);
        } else if (type === 'result') {
          worker.terminate();
          resolve(hash);
        } else if (type === 'error') {
          worker.terminate();
          reject(new Error(error));
        }
      };
      
      worker.onerror = (e) => {
        worker.terminate();
        reject(new Error('计算文件指纹失败'));
      };
      
      worker.postMessage({ file, chunkSize: 8 * 1024 * 1024 });
    });
  };

  // 上传单个文件（断点续传版，带进度回调，支持并发上传）
  const uploadSingleFile = async (
    file: File, 
    folderId: string,
    onProgress?: (uploadedBytes: number) => void,
    onSpeed?: (speedBytesPerSec: number) => void
  ): Promise<void> => {
    const token = authToken || localStorage.getItem('auth_token');
    
    // 1. 计算文件内容哈希（作为唯一标识，确保内容相同才是同一个文件）
    const fileHash = await calculateFileHash(file);
    const fileId = fileHash; // 使用文件内容哈希作为唯一 ID
    
    // 2. 先检查秒传（如果服务器上已有相同文件，直接秒传）
    const quickRes = await fetch('/api/files/upload/quick', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify({
        fileHash: fileHash,
        filename: file.name,
        mimeType: file.type || 'application/octet-stream',
        folderId
      })
    });
    
    if (quickRes.ok) {
      const quickData = await quickRes.json();
      if (quickData.exists) {
        // 秒传成功！
        if (onProgress) onProgress(file.size);
        return; // 直接返回，跳过上传
      }
    }
    
    // 3. 检查上传状态（断点续传的核心）
    const statusRes = await fetch(`/api/files/upload/status?fileId=${encodeURIComponent(fileId)}`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    
    if (!statusRes.ok) {
      const errData = await statusRes.json();
      throw new Error(errData.error || '获取上传状态失败');
    }
    
    const { uploadedBytes } = await statusRes.json();
    let currentByte = uploadedBytes;
    
    // 通知初始进度
    if (onProgress) onProgress(currentByte);
    
    const startTime = Date.now();
    let lastLoaded = currentByte;
    let lastTime = startTime;
    
    // 4. 串行上传分片
    while (currentByte < file.size) {
      // 检查是否取消
      if (uploadCancelRequestedRef.current) {
        throw new Error('上传已取消');
      }
      
      // 检查是否暂停（暂停则中断，用户点击继续时会重新调用，从断点继续）
      if (isUploadPausedRef.current) {
        throw new Error('上传已暂停，点击继续可断点续传');
      }
      
      // 切割分片 - 使用配置的分片大小
      const CHUNK_SIZE = getChunkSize();
      const endByte = Math.min(currentByte + CHUNK_SIZE, file.size);
      const chunk = file.slice(currentByte, endByte);
      
      try {
        // 上传分片（流式追加）
        const chunkRes = await fetch('/api/files/upload/append', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/octet-stream',
            'x-file-id': fileId,
            'x-start-byte': currentByte.toString(),
            ...(token ? { 'Authorization': `Bearer ${token}` } : {})
          },
          body: chunk
        });
        
        if (!chunkRes.ok) {
          const errData = await chunkRes.json();
          throw new Error(errData.error || '上传失败');
        }
        
        const result = await chunkRes.json();
        currentByte = result.uploadedBytes;
        
        // 通知进度
        if (onProgress) onProgress(currentByte);
        
        // 计算速度
        const now = Date.now();
        const elapsed = (now - lastTime) / 1000;
        if (elapsed > 0.3 && onSpeed) {
          const bytesPerSecond = (currentByte - lastLoaded) / elapsed;
          onSpeed(bytesPerSecond);
          lastLoaded = currentByte;
          lastTime = now;
        }
        
      } catch (error: any) {
        // 如果是 409 错误（文件指针不匹配），重新获取状态后继续
        if (error.message && error.message.includes('文件指针不匹配')) {
          const statusRes2 = await fetch(`/api/files/upload/status?fileId=${encodeURIComponent(fileId)}`, {
            headers: token ? { 'Authorization': `Bearer ${token}` } : {}
          });
          if (statusRes2.ok) {
            const { uploadedBytes: newUploadedBytes } = await statusRes2.json();
            currentByte = newUploadedBytes;
            continue;
          }
        }
        throw error;
      }
    }
    
    // 5. 上传完成，调用 complete 接口写入数据库
    const completeRes = await fetch('/api/files/upload/complete', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify({
        fileId,
        filename: file.name,
        mimeType: file.type || 'application/octet-stream',
        folderId
      })
    });
    
    if (!completeRes.ok) {
      const errData = await completeRes.json();
      throw new Error(errData.error || '上传完成失败');
    }
  };

  const uploadFilesBatch = async (filesArray: File[]) => {
    setIsUploading(true);
    setUploadProgress(0);
    setUploadSpeed('0 KB/s');
    setUploadingFileName(`共 ${filesArray.length} 个文件`);

    const MAX_CONCURRENT = 3; // 最大并发数
    const totalSize = filesArray.reduce((sum, f) => sum + f.size, 0);
    const fileProgress = new Map<string, number>(); // 每个文件的已上传字节数
    let totalSpeed = 0; // 总速度
    let successCount = 0;
    let failedCount = 0;

    // 格式化速度
    const formatSpeed = (bytesPerSec: number): string => {
      if (bytesPerSec >= 1024 * 1024) {
        return (bytesPerSec / (1024 * 1024)).toFixed(2) + ' MB/s';
      } else if (bytesPerSec >= 1024) {
        return (bytesPerSec / 1024).toFixed(1) + ' KB/s';
      } else {
        return bytesPerSec.toFixed(0) + ' B/s';
      }
    };

    // 更新总进度
    const updateTotalProgress = () => {
      let uploaded = 0;
      fileProgress.forEach((bytes) => { uploaded += bytes; });
      const percent = Math.round((uploaded / totalSize) * 100);
      setUploadProgress(percent);
    };

    // 并发控制器
    let currentIndex = 0;
    let activeCount = 0;
    let hasError = false;
    let firstError: Error | null = null;

    const uploadNext = async (): Promise<void> => {
      if (hasError) return;
      if (currentIndex >= filesArray.length) return;

      const fileIndex = currentIndex++;
      const file = filesArray[fileIndex];
      activeCount++;

      try {
        // 初始化该文件的进度
        fileProgress.set(file.name, 0);

        await uploadSingleFile(
          file, 
          currentFolderId,
          (uploadedBytes) => {
            // 进度回调
            fileProgress.set(file.name, uploadedBytes);
            updateTotalProgress();
          },
          (speedBytes) => {
            // 速度回调（简单累加，可能不够精确，但够用）
            totalSpeed = speedBytes * Math.min(activeCount, MAX_CONCURRENT);
            setUploadSpeed(formatSpeed(totalSpeed));
          }
        );

        successCount++;
        fileProgress.set(file.name, file.size);
        updateTotalProgress();

      } catch (error: any) {
        failedCount++;
        if (!hasError) {
          hasError = true;
          firstError = error;
        }
      } finally {
        activeCount--;
        
        // 继续上传下一个
        if (!hasError && currentIndex < filesArray.length) {
          await uploadNext();
        }
      }
    };

    try {
      // 启动初始并发任务
      const initialPromises: Promise<void>[] = [];
      for (let i = 0; i < Math.min(MAX_CONCURRENT, filesArray.length); i++) {
        initialPromises.push(uploadNext());
      }
      
      await Promise.all(initialPromises);

      // 等待所有活跃任务完成
      while (activeCount > 0) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      if (hasError && firstError) {
        throw firstError;
      }

      // 全部上传完成后再刷新一次文件列表
      await fetchDriveContents();
      
      setUploadSpeed(`完成 ${successCount} 个文件`);

    } catch (error: any) {
      console.error('上传失败:', error);
      alert(error.message || '上传失败');
      // 出错后也刷新一下，显示已上传的文件
      if (successCount > 0) {
        await fetchDriveContents();
      }
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      setUploadSpeed('0 KB/s');
      setUploadingFileName('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };


  // Drag and Drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await uploadFilesBatch(Array.from(e.dataTransfer.files));
    }
  };

  // Create New Folder
  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;

    try {
      const res = await customFetch("/api/folders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newFolderName.trim(),
          parentId: currentFolderId
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to create folder");
      }

      setSuccessMessage("文件夹创建成功");
      setNewFolderName("");
      setIsNewFolderOpen(false);
      fetchDriveContents();
    } catch (err: any) {
      setErrorMessage(err.message || "创建文件夹失败");
    }
  };

  // Delete Folder
  const handleDeleteFolder = async (folderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("确定要将此文件夹及其所有内容移动到回收站吗？")) return;

    const folderToRestore = folders.find(f => f.id === folderId);
    // Optimistic Update: instantly remove folder
    setFolders(prev => prev.filter(f => f.id !== folderId));

    try {
      const res = await customFetch(`/api/folders/${folderId}`, {
        method: "DELETE"
      });

      if (!res.ok) throw new Error("Failed to move folder to trash");

      setSuccessMessage("文件夹已成功移动至回收站");
      fetchStats();
    } catch (err: any) {
      // Rollback on error
      if (folderToRestore) {
        setFolders(prev => [...prev, folderToRestore]);
      }
      setErrorMessage(err.message || "移动文件夹至回收站失败");
    }
  };

  // Rename Folder
  const handleRenameFolderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTargetFolder || !renameInputName.trim()) return;

    try {
      const res = await customFetch(`/api/folders/${renameTargetFolder.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: renameInputName.trim() })
      });

      if (!res.ok) throw new Error("Failed to rename folder");

      setSuccessMessage("文件夹重命名成功");
      setRenameTargetFolder(null);
      setRenameInputName("");
      fetchDriveContents();
    } catch (err: any) {
      setErrorMessage(err.message || "重命名文件夹失败");
    }
  };

  // Delete File (Move to Trash)
  const handleDeleteFile = async (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("确定要将此文件移动到回收站吗？")) return;

    const fileToRestore = files.find(f => f.id === fileId);
    // Optimistic Update: instantly remove file
    setFiles(prev => prev.filter(f => f.id !== fileId));

    try {
      const res = await customFetch(`/api/files/${fileId}`, {
        method: "DELETE"
      });

      if (!res.ok) throw new Error("Failed to move file to trash");

      setSuccessMessage("文件已成功移动至回收站");
      fetchStats();
      
      // If deleted while previewing, close preview
      if (previewFile?.id === fileId) {
        setPreviewFile(null);
      }
    } catch (err: any) {
      // Rollback on error
      if (fileToRestore) {
        setFiles(prev => [...prev, fileToRestore]);
      }
      setErrorMessage(err.message || "移动文件至回收站失败");
    }
  };

  // Restore file from trash
  const handleRestoreFile = async (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await customFetch("/api/trash/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "file", id: fileId })
      });
      if (!res.ok) throw new Error("Failed to restore file");
      setSuccessMessage("文件恢复成功");
      fetchDriveContents();
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "恢复文件失败");
    }
  };

  // Permanently delete file from trash
  const handlePermanentlyDeleteFile = async (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("此操作将永久删除该文件且无法恢复，确定吗？")) return;
    try {
      const res = await customFetch("/api/trash/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "file", id: fileId })
      });
      if (!res.ok) throw new Error("Failed to permanently delete file");
      setSuccessMessage("文件已永久删除");
      fetchDriveContents();
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "永久删除文件失败");
    }
  };

  // Restore folder from trash
  const handleRestoreFolder = async (folderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await customFetch("/api/trash/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "folder", id: folderId })
      });
      if (!res.ok) throw new Error("Failed to restore folder");
      setSuccessMessage("文件夹恢复成功");
      fetchDriveContents();
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "恢复文件夹失败");
    }
  };

  // Permanently delete folder from trash
  const handlePermanentlyDeleteFolder = async (folderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("此操作将永久删除该文件夹及其所有内容且无法恢复，确定吗？")) return;
    try {
      const res = await customFetch("/api/trash/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "folder", id: folderId })
      });
      if (!res.ok) throw new Error("Failed to permanently delete folder");
      setSuccessMessage("文件夹已永久删除");
      fetchDriveContents();
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "永久删除文件夹失败");
    }
  };

  // Empty Recycle Bin
  const handleEmptyTrash = async () => {
    if (!confirm("确定要完全清空回收站吗？此操作将永久删除其中的所有文件和文件夹，且绝对无法恢复。")) return;
    try {
      const res = await customFetch("/api/trash/empty", {
        method: "POST"
      });
      if (!res.ok) throw new Error("Failed to empty trash");
      setSuccessMessage("回收站已完全清空");
      fetchDriveContents();
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "清空回收站失败");
    }
  };

  // Open Move/Copy modal
  const openMoveCopyModal = async (file: DriveFile, type: "move" | "copy") => {
    setMoveCopyTargetFile(file);
    setMoveCopyType(type);
    setMoveCopySelectedFolderId(file.folder_id || "");
    try {
      const res = await customFetch("/api/folders/all");
      if (res.ok) {
        const data = await res.json();
        setAllFoldersList(data || []);
      }
      setIsMoveCopyOpen(true);
    } catch (err: any) {
      setErrorMessage("加载文件夹列表失败");
    }
  };

  // Handle Move/Copy submission
  const handleMoveCopySubmit = async () => {
    if (!moveCopyTargetFile) return;
    try {
      const endpoint = moveCopyType === "move" ? "/api/files/move" : "/api/files/copy";
      const res = await customFetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileId: moveCopyTargetFile.id,
          targetFolderId: moveCopySelectedFolderId
        })
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "操作失败");
      }
      setSuccessMessage(moveCopyType === "move" ? "文件移动成功" : "文件复制成功");
      setIsMoveCopyOpen(false);
      setMoveCopyTargetFile(null);
      fetchDriveContents();
      fetchStats();
    } catch (err: any) {
      setErrorMessage(err.message || "文件操作失败");
    }
  };

  // Rename File
  const handleRenameFileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTargetFile || !renameInputName.trim()) return;

    try {
      const res = await customFetch(`/api/files/${renameTargetFile.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: renameInputName.trim() })
      });

      if (!res.ok) throw new Error("Failed to rename file");

      setSuccessMessage("文件重命名成功");
      setRenameTargetFile(null);
      setRenameInputName("");
      fetchDriveContents();
    } catch (err: any) {
      setErrorMessage(err.message || "重命名文件失败");
    }
  };

  // Toggle Favorite
  const toggleFavorite = async (file: DriveFile, e: React.MouseEvent) => {
    e.stopPropagation();
    const newFavState = file.is_favorite === 1 ? 0 : 1;

    // Optimistic Update: instantly toggle favorite star
    setFiles(prev => prev.map(f => f.id === file.id ? { ...f, is_favorite: newFavState } : f));
    
    try {
      const res = await customFetch(`/api/files/${file.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFavorite: newFavState === 1 })
      });

      if (!res.ok) throw new Error("Failed to update favorite status");
      
      fetchStats();
      setSuccessMessage(newFavState === 1 ? "已添加到收藏夹" : "已移出收藏夹");
    } catch (err: any) {
      // Rollback on error
      setFiles(prev => prev.map(f => f.id === file.id ? { ...f, is_favorite: file.is_favorite } : f));
      setErrorMessage(err.message || "修改收藏状态失败");
    }
  };

  // Image Preview Panning / Dragging Handlers
  const handleImgMouseDown = (e: React.MouseEvent<HTMLImageElement>) => {
    e.preventDefault();
    setIsDraggingImage(true);
    setImageDragStart({ x: e.clientX - imageOffset.x, y: e.clientY - imageOffset.y });
  };

  const handleImgMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDraggingImage) return;
    setImageOffset({
      x: e.clientX - imageDragStart.x,
      y: e.clientY - imageDragStart.y
    });
  };

  const handleImgMouseUp = () => {
    setIsDraggingImage(false);
    touchStartDistRef.current = null;
  };

  const getTouchDistance = (touches: React.TouchList) => {
    if (touches.length < 2) return 0;
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  };

  const handleImgTouchStart = (e: React.TouchEvent<HTMLImageElement>) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      setIsDraggingImage(true);
      setImageDragStart({ x: touch.clientX - imageOffset.x, y: touch.clientY - imageOffset.y });
      touchStartDistRef.current = null;
    } else if (e.touches.length === 2) {
      setIsDraggingImage(false);
      const dist = getTouchDistance(e.touches);
      touchStartDistRef.current = dist;
      touchStartZoomRef.current = imageZoom;
    }
  };

  const handleImgTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.cancelable) {
      e.preventDefault();
    }

    if (e.touches.length === 1 && isDraggingImage) {
      const touch = e.touches[0];
      setImageOffset({
        x: touch.clientX - imageDragStart.x,
        y: touch.clientY - imageDragStart.y
      });
    } else if (e.touches.length === 2 && touchStartDistRef.current !== null) {
      const dist = getTouchDistance(e.touches);
      if (dist > 0) {
        const scale = dist / touchStartDistRef.current;
        const newZoom = Math.max(0.4, Math.min(6, touchStartZoomRef.current * scale));
        setImageZoom(newZoom);
      }
    }
  };

  const handleImgDoubleClick = () => {
    if (imageZoom > 1.2) {
      setImageZoom(1);
      setImageOffset({ x: 0, y: 0 });
    } else {
      setImageZoom(2.5);
    }
  };

  // Listen for Middle Mouse Button / Wheel zoom in preview container
  useEffect(() => {
    const container = imgContainerRef.current;
    if (!container) return;

    const handleWheelEvent = (e: WheelEvent) => {
      e.preventDefault();
      const zoomFactor = 0.08;
      if (e.deltaY < 0) {
        setImageZoom(z => Math.min(6, z + zoomFactor));
      } else {
        setImageZoom(z => Math.max(0.4, z - zoomFactor));
      }
    };

    container.addEventListener("wheel", handleWheelEvent, { passive: false });
    return () => {
      container.removeEventListener("wheel", handleWheelEvent);
    };
  }, [previewFile]);

  // Open Preview Modal
  const openFilePreview = async (file: DriveFile) => {
    setPreviewFile(file);
    setImageZoom(1);
    setImageRotation(0);
    setImageOffset({ x: 0, y: 0 });
    setPreviewTextContent(null);
    setShowPreviewSidebar(window.innerWidth >= 768);

    // If it's text/code file, fetch its raw text content
    if (file.mime_type.startsWith("text/") || file.mime_type === "application/json") {
      try {
        const res = await customFetch(`/api/files/text/${file.id}`);
        if (res.ok) {
          const data = await res.json();
          setPreviewTextContent(data.text);
        }
      } catch (err) {
        console.error("Failed to fetch text content:", err);
        setPreviewTextContent("无法读取文件内容或文件包含二进制数据。");
      }
    }
  };

  // Get Styling Class & Icon for different File Types
  const getFileStyleAndIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) {
      return {
        icon: ImageIcon,
        bgClass: "bg-emerald-50 text-emerald-600 border-emerald-100",
        btnClass: "text-emerald-600 hover:bg-emerald-50",
        badge: "图片",
        colorTheme: "emerald"
      };
    } else if (mimeType.startsWith("video/")) {
      return {
        icon: VideoIcon,
        bgClass: "bg-fuchsia-50 text-fuchsia-600 border-fuchsia-100",
        btnClass: "text-fuchsia-600 hover:bg-fuchsia-50",
        badge: "视频",
        colorTheme: "fuchsia"
      };
    } else if (mimeType.startsWith("audio/")) {
      return {
        icon: MusicIcon,
        bgClass: "bg-indigo-50 text-indigo-600 border-indigo-100",
        btnClass: "text-indigo-600 hover:bg-indigo-50",
        badge: "音频",
        colorTheme: "indigo"
      };
    } else if (
      mimeType.startsWith("text/") || 
      mimeType === "application/pdf" ||
      mimeType.includes("word") ||
      mimeType.includes("excel") ||
      mimeType.includes("powerpoint")
    ) {
      return {
        icon: FileText,
        bgClass: "bg-sky-50 text-sky-600 border-sky-100",
        btnClass: "text-sky-600 hover:bg-sky-50",
        badge: "文档",
        colorTheme: "sky"
      };
    } else {
      return {
        icon: File,
        bgClass: "bg-slate-50 text-slate-600 border-slate-100",
        btnClass: "text-slate-600 hover:bg-slate-50",
        badge: "其他",
        colorTheme: "slate"
      };
    }
  };

  // Stats Breakdown calculation
  const totalLimit = 10 * 1024 * 1024 * 1024; // Mock 10GB limit
  const spaceUsedPercent = stats ? Math.min(100, (stats.totalSize / totalLimit) * 100) : 0;

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#09090b] text-[#fafafa] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-4 border-[#27272a] border-t-[#3b82f6] animate-spin" />
          <p className="text-zinc-400 text-sm font-medium">正在加载个人云盘...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#09090b] text-[#fafafa] flex items-center justify-center p-4">
        {/* TOAST NOTIFICATIONS */}
        <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
          <AnimatePresence>
            {errorMessage && (
              <motion.div 
                initial={{ opacity: 0, y: -20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.95 }}
                className="bg-[#18181b] border border-rose-500/30 border-l-4 border-l-rose-500 text-rose-200 p-4 rounded-lg shadow-lg flex items-center gap-3 max-w-sm pointer-events-auto"
              >
                <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
                <div className="text-sm font-medium">{errorMessage}</div>
                <button onClick={() => setErrorMessage(null)} className="ml-auto text-rose-500 hover:text-rose-700">
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            )}

            {successMessage && (
              <motion.div 
                initial={{ opacity: 0, y: -20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.95 }}
                className="bg-[#18181b] border border-emerald-500/30 border-l-4 border-l-emerald-500 text-emerald-200 p-4 rounded-lg shadow-lg flex items-center gap-3 max-w-sm pointer-events-auto"
              >
                <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs shrink-0 font-bold">✓</div>
                <div className="text-sm font-medium">{successMessage}</div>
                <button onClick={() => setSuccessMessage(null)} className="ml-auto text-emerald-500 hover:text-emerald-700">
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="w-full max-w-md bg-[#111114] border border-[#27272a] rounded-2xl shadow-2xl p-6 md:p-8 flex flex-col gap-6">
          <div className="flex flex-col items-center gap-3 text-center">
            <div className="w-12 h-12 rounded-xl bg-[#3b82f6] flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <HardDrive className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-white text-2xl leading-tight">
                {hasUsers ? (authMode === "login" ? "用户登录" : "用户注册") : "创建管理员账号"}
              </h1>
              <p className="text-zinc-500 text-xs mt-1 max-w-xs">
                {hasUsers 
                  ? (authMode === "login" ? "请输入用户名和密码以访问您的个人云网盘" : "请设置您的新账号用户名和密码") 
                  : "由于系统尚未注册任何账号，请设置第一个管理员账号以初始化系统"}
              </p>
            </div>
          </div>

          <form onSubmit={handleAuthSubmit} className="flex flex-col gap-4">
            {authError && (
              <div className="bg-rose-950/20 border border-rose-900/40 text-rose-400 p-3.5 rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">用户名</label>
              <input
                type="text"
                value={authUsername}
                onChange={(e) => setAuthUsername(e.target.value)}
                placeholder="请输入用户名..."
                required
                className="w-full px-4 py-2.5 bg-[#18181b] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] transition-all placeholder:text-zinc-600"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">密码</label>
              <input
                type="password"
                value={authPassword}
                onChange={(e) => setAuthPassword(e.target.value)}
                placeholder="请输入密码..."
                required
                className="w-full px-4 py-2.5 bg-[#18181b] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] transition-all placeholder:text-zinc-600"
              />
            </div>

            <button
              type="submit"
              disabled={isAuthSubmitting}
              className="w-full mt-2 py-2.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-500/10 hover:shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isAuthSubmitting ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : null}
              <span>{hasUsers ? (authMode === "login" ? "登录" : "注册") : "创建管理员并登录"}</span>
            </button>
          </form>

          {hasUsers && (
            <div className="text-center border-t border-[#27272a] pt-4">
              <button
                onClick={() => {
                  setAuthMode(authMode === "login" ? "register" : "login");
                  setAuthError(null);
                }}
                className="text-xs text-[#3b82f6] hover:underline cursor-pointer"
              >
                {authMode === "login" ? "注册新账号" : "已有账号？立即登录"}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-[#09090b] text-[#fafafa] flex flex-col md:flex-row relative outline-none"
      onDragEnter={handleDrag}
      ref={dropZoneRef}
    >
      {/* 1. TOAST NOTIFICATIONS */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
          {errorMessage && (
            <motion.div 
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              className="bg-[#18181b] border border-rose-500/30 border-l-4 border-l-rose-500 text-rose-200 p-4 rounded-lg shadow-lg flex items-center gap-3 max-w-sm pointer-events-auto"
            >
              <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
              <div className="text-sm font-medium">{errorMessage}</div>
              <button onClick={() => setErrorMessage(null)} className="ml-auto text-rose-500 hover:text-rose-700">
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {successMessage && (
            <motion.div 
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              className="bg-[#18181b] border border-emerald-500/30 border-l-4 border-l-emerald-500 text-emerald-200 p-4 rounded-lg shadow-lg flex items-center gap-3 max-w-sm pointer-events-auto"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs shrink-0 font-bold">✓</div>
              <div className="text-sm font-medium">{successMessage}</div>
              <button onClick={() => setSuccessMessage(null)} className="ml-auto text-emerald-500 hover:text-emerald-700">
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 2. DRAG & DROP OVERLAY DROPZONE */}
      <AnimatePresence>
        {dragActive && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-indigo-600/10 backdrop-blur-sm z-40 border-4 border-dashed border-indigo-500 m-4 rounded-2xl flex flex-col items-center justify-center pointer-events-none"
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="bg-white p-6 rounded-2xl shadow-xl flex flex-col items-center gap-4 max-w-sm text-center pointer-events-auto">
              <div className="w-16 h-16 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center animate-bounce">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-800">拖拽文件至此上传</h3>
                <p className="text-sm text-slate-500 mt-1">支持图片、视频、音乐及各类常用文档直接拖拽上传</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. SIDEBAR */}
      <aside className={`${isMobileMenuOpen ? 'flex' : 'hidden'} md:flex absolute inset-0 z-50 md:fixed md:left-0 md:top-0 w-full md:w-64 bg-[#111114] border-r border-[#27272a] shrink-0 flex flex-col p-6 gap-6 text-[#fafafa] h-screen overflow-y-auto`}>
        {/* Mobile Close Button */}
        <button
          onClick={() => setIsMobileMenuOpen(false)}
          className="md:hidden absolute top-4 right-4 p-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-zinc-400 hover:text-white transition-colors cursor-pointer"
          title="关闭菜单"
        >
          <X className="w-5 h-5" />
        </button>
        {/* Brand Logo */}
        <div className="flex items-center gap-3 pb-2 border-b border-[#27272a]">
          <div className="w-10 h-10 rounded-xl bg-[#3b82f6] flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-white text-lg leading-tight">个人云网盘</h1>
            <span className="text-[11px] font-medium text-[#3b82f6] tracking-wider uppercase">SQLite Edition</span>
          </div>
        </div>

        {/* Navigation Categories */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[10px] font-bold text-zinc-500 tracking-wider uppercase mb-1 px-3">文件库</span>
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("all"); setFileTypeFilter("all"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "all" && fileTypeFilter === "all"
                ? "bg-[#1e1e2e] text-[#3b82f6] font-semibold animate-pulse-subtle"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <HardDrive className="w-4.5 h-4.5" />
            <span>全部文件</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("photos-videos"); setFileTypeFilter("images"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "photos-videos"
                ? "bg-[#1e1e2e] text-[#3b82f6] font-semibold"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <ImageIcon className="w-4.5 h-4.5" />
            <span>图片与视频</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("favorites"); setFileTypeFilter("all"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "favorites"
                ? "bg-[#1e1e2e] text-[#3b82f6] font-semibold"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <Star className="w-4.5 h-4.5 fill-current" />
            <span>我的收藏</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("trash"); setFileTypeFilter("all"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "trash"
                ? "bg-rose-950/30 text-rose-400 border border-rose-900/20 font-semibold"
                : "text-zinc-400 hover:bg-rose-950/10 hover:text-rose-400"
            }`}
          >
            <Trash2 className="w-4.5 h-4.5" />
            <span>回收站</span>
          </motion.button>

          {/* Shared Links Tab */}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("shared-links"); setFileTypeFilter("all"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "shared-links"
                ? "bg-sky-950/40 text-sky-400 border border-sky-900/20 font-semibold"
                : "text-zinc-400 hover:bg-sky-950/10 hover:text-sky-400"
            }`}
          >
            <Share2 className="w-4.5 h-4.5" />
            <span>分享链接</span>
          </motion.button>
        </div>

        {/* Quick Filter Types */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[10px] font-bold text-zinc-500 tracking-wider uppercase mb-1 px-3">快速过滤</span>
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("all"); setFileTypeFilter("images"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "all" && fileTypeFilter === "images"
                ? "bg-emerald-950/40 text-emerald-400 font-semibold"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <ImageIcon className="w-4.5 h-4.5" />
            <span>图片</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("all"); setFileTypeFilter("videos"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "all" && fileTypeFilter === "videos"
                ? "bg-fuchsia-950/40 text-fuchsia-400 font-semibold"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <VideoIcon className="w-4.5 h-4.5" />
            <span>视频</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("all"); setFileTypeFilter("audio"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "all" && fileTypeFilter === "audio"
                ? "bg-[#1e1e2e] text-[#3b82f6] font-semibold"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <MusicIcon className="w-4.5 h-4.5" />
            <span>音频</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { if (isFetchingContents) return; setActiveTab("all"); setFileTypeFilter("documents"); }}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
              activeTab === "all" && fileTypeFilter === "documents"
                ? "bg-sky-950/40 text-sky-400 font-semibold"
                : "text-zinc-400 hover:bg-zinc-900/60 hover:text-zinc-100"
            }`}
          >
            <FileText className="w-4.5 h-4.5" />
            <span>文档</span>
          </motion.button>
        </div>

        {/* Space Usage Progress */}
        <div className="mt-auto pt-4 border-t border-[#27272a] flex flex-col gap-3">
          <div className="flex justify-between text-xs font-semibold text-zinc-300">
            <span className="flex items-center gap-1.5"><HardDrive className="w-3.5 h-3.5" /> 空间容量</span>
            <span>{stats ? formatBytes(stats.totalSize) : "0 B"} / 无限制</span>
          </div>
          
          <div className="w-full bg-[#18181b] h-2.5 rounded-full overflow-hidden border border-[#27272a]">
            <div 
              className="bg-emerald-500 h-full rounded-full transition-all duration-500 ease-out shadow-[0_0_8px_rgba(16,185,129,0.5)]"
              style={{ width: "100%" }}
            />
          </div>

          <div className="flex justify-between text-[11px] text-zinc-500">
            <span className="text-emerald-400 font-medium">无限空间已启用</span>
            <span>共 {stats?.totalCount || 0} 个文件</span>
          </div>
        </div>

        {/* 实时系统信息 */}
        <div className="pt-4 border-t border-[#27272a] flex flex-col gap-2.5">
          <div className="flex justify-between items-center text-xs font-semibold text-zinc-300">
            <span className="flex items-center gap-1.5">
              <div className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'}`} />
              系统状态
            </span>
            <span className="text-[10px] text-zinc-500">实时</span>
          </div>
          
          {systemInfo ? (
            <>
              {/* CPU */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-[11px] text-zinc-400">
                  <span>CPU</span>
                  <span className="font-medium text-zinc-300">{systemInfo.cpu?.usage || '0.0'}%</span>
                </div>
                <div className="w-full bg-[#18181b] h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-blue-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, parseFloat(systemInfo.cpu?.usage || '0'))}%` }}
                  />
                </div>
              </div>

              {/* 内存 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-[11px] text-zinc-400">
                  <span>内存</span>
                  <span className="font-medium text-zinc-300">
                    {formatBytes(systemInfo.memory?.used || 0)} / {formatBytes(systemInfo.memory?.total || 0)}
                  </span>
                </div>
                <div className="w-full bg-[#18181b] h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-purple-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, parseFloat(systemInfo.memory?.usage || '0'))}%` }}
                  />
                </div>
              </div>

              {/* 磁盘 */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-[11px] text-zinc-400">
                  <span>磁盘</span>
                  <span className="font-medium text-zinc-300">
                    {formatBytes(systemInfo.disk?.used || 0)} / {formatBytes(systemInfo.disk?.total || 0)}
                  </span>
                </div>
                <div className="w-full bg-[#18181b] h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-amber-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, parseFloat(systemInfo.disk?.usage || '0'))}%` }}
                  />
                </div>
              </div>

              {/* 运行时间 */}
              <div className="flex justify-between text-[11px] text-zinc-400 pt-1">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  运行时间
                </span>
                <span className="font-medium text-zinc-300">
                  {systemInfo.system?.uptimeFormatted || '未知'}
                </span>
              </div>
            </>
          ) : (
            <div className="text-[11px] text-zinc-500 text-center py-2">
              连接中...
            </div>
          )}
        </div>

        {/* User profile and logout button */}
        <div className="mt-auto pt-4 border-t border-[#27272a] flex flex-col gap-3">
          <div className="flex items-center gap-2.5 px-1 bg-[#18181b]/40 p-2.5 rounded-xl border border-[#27272a]/40">
            <div className="w-8 h-8 rounded-full bg-blue-600/15 border border-blue-500/20 text-[#3b82f6] flex items-center justify-center font-bold text-xs select-none uppercase shrink-0">
              {currentUser ? currentUser.username[0] : "U"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-white truncate" title={currentUser?.username}>
                {currentUser?.username}
              </p>
              <p className="text-[10px] text-zinc-500 font-medium">在线云端</p>
            </div>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-1.5 bg-zinc-800/50 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-lg border border-zinc-700/50 hover:border-zinc-600 transition-all cursor-pointer shrink-0"
              title="设置"
            >
              <Settings className="w-4 h-4" />
            </button>
            <button
              onClick={handleLogout}
              className="p-1.5 bg-rose-500/10 hover:bg-rose-550 text-rose-500 hover:text-white rounded-lg border border-rose-500/20 hover:border-rose-500/40 transition-all cursor-pointer shrink-0"
              title="登出账号"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* 4. MAIN CONTENT PANEL */}
      <main className="flex-1 flex flex-col min-w-0 p-4 md:p-8 md:pl-72 gap-6">
        
        {/* Top Control Bar (Search & Quick Action) */}
        <section className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 bg-[#111114] p-4 rounded-2xl border border-[#27272a] shadow-lg">
          
          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(true)}
            className="md:hidden flex items-center justify-center p-2.5 bg-[#18181b] hover:bg-zinc-800 border border-[#27272a] text-zinc-400 hover:text-white rounded-xl transition-colors cursor-pointer shrink-0"
            title="打开菜单"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Search Box */}
          <div className="flex-1 max-w-md relative">
            <Search className="w-5 h-5 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="搜索网盘内的任何文件...（按回车搜索）"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              className="w-full pl-11 pr-10 py-2.5 bg-[#18181b] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] transition-all placeholder:text-zinc-500"
            />
            {searchInput && (
              <button 
                onClick={() => { setSearchInput(""); setSearchQuery(""); }} 
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3">
            {activeTab === "trash" ? (
              <button
                onClick={handleEmptyTrash}
                className="flex items-center gap-2 px-4 py-2.5 border border-rose-950/40 hover:border-rose-900 bg-rose-950/20 hover:bg-rose-950/40 text-rose-400 font-semibold text-sm rounded-xl transition-all cursor-pointer shadow-xs shrink-0"
              >
                <Trash2 className="w-4.5 h-4.5" />
                <span>清空回收站</span>
              </button>
            ) : (
              <>
                <button
                  onClick={() => setIsNewFolderOpen(true)}
                  className="flex items-center gap-2 px-4 py-2.5 border border-[#27272a] hover:border-[#3f3f46] bg-[#18181b] hover:bg-[#27272a] text-zinc-200 font-semibold text-sm rounded-xl transition-all cursor-pointer shadow-xs shrink-0"
                >
                  <FolderPlus className="w-4.5 h-4.5 text-[#3b82f6]" />
                  <span>新建文件夹</span>
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="flex items-center gap-2 px-4 py-2.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-500/10 hover:shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50 shrink-0"
                >
                  <Upload className="w-4.5 h-4.5" />
                  <span>{isUploading ? `上传中 (${uploadProgress}%)` : "上传文件"}</span>
                </button>
              </>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              multiple
            />
          </div>
        </section>

        {/* Storage Stats breakdown dashboard banner */}
        <section className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {[
            { label: "图片", size: stats?.categories.images.size || 0, count: stats?.categories.images.count || 0, color: "text-emerald-400 bg-emerald-950/20 border-emerald-900/30", icon: ImageIcon },
            { label: "视频", size: stats?.categories.videos.size || 0, count: stats?.categories.videos.count || 0, color: "text-fuchsia-400 bg-fuchsia-950/20 border-fuchsia-900/30", icon: VideoIcon },
            { label: "音频", size: stats?.categories.audio.size || 0, count: stats?.categories.audio.count || 0, color: "text-blue-400 bg-blue-950/20 border-blue-900/30", icon: MusicIcon },
            { label: "文档", size: stats?.categories.documents.size || 0, count: stats?.categories.documents.count || 0, color: "text-sky-400 bg-sky-950/20 border-sky-900/30", icon: FileText },
            { label: "其他", size: stats?.categories.others.size || 0, count: stats?.categories.others.count || 0, color: "text-zinc-400 bg-zinc-900/40 border-zinc-800/55", icon: File }
          ].map((cat, i) => (
            <div key={i} className={`p-3 rounded-xl border flex items-center gap-3 bg-[#111114] shadow-xs ${cat.color.split(" ").slice(2).join(" ")}`}>
              <div className={`p-2 rounded-lg ${cat.color.split(" ")[1]} shrink-0`}>
                <cat.icon className="w-4.5 h-4.5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">{cat.label}</p>
                <p className="text-sm font-semibold text-white mt-0.5 truncate">{formatBytes(cat.size, 1)}</p>
                <p className="text-[10px] text-zinc-400 font-medium mt-0.5">{cat.count} 个文件</p>
              </div>
            </div>
          ))}
        </section>

        {/* Breadcrumb Path Navigator */}
        <section className="flex items-center justify-between bg-[#111114] border border-[#27272a] p-3 px-4 rounded-xl shadow-lg">
          <div className="flex items-center gap-1.5 flex-wrap text-sm font-medium">
            <button
              onClick={() => handleBreadcrumbClick("", -1)}
              className="text-zinc-400 hover:text-[#3b82f6] flex items-center gap-1 transition-colors cursor-pointer"
            >
              <HardDrive className="w-4 h-4" />
              <span>全部文件</span>
            </button>
            
            {breadcrumbs.map((crumb, idx) => (
              <React.Fragment key={crumb.id}>
                <ChevronRight className="w-4 h-4 text-zinc-700 shrink-0" />
                <button
                  onClick={() => handleBreadcrumbClick(crumb.id, idx)}
                  className="text-zinc-200 hover:text-[#3b82f6] font-medium transition-colors truncate max-w-[150px] cursor-pointer"
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            ))}
          </div>

          {/* Sort & Order settings */}
          <div className="flex items-center gap-2">
            <div className="flex bg-[#18181b] p-1 rounded-lg gap-1 border border-[#27272a]">
              {[
                { field: "created_at", label: "日期" },
                { field: "name", label: "名称" },
                { field: "size", label: "大小" }
              ].map((item) => (
                <button
                  key={item.field}
                  onClick={() => setSortField(item.field as any)}
                  className={`text-sm px-3 py-2 rounded-md font-semibold transition-colors cursor-pointer ${
                    sortField === item.field 
                      ? "bg-zinc-800 text-white shadow-xs" 
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => setSortOrder(sortOrder === "ASC" ? "DESC" : "ASC")}
              className="p-2 bg-[#18181b] hover:bg-zinc-800 border border-[#27272a] text-zinc-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              title={sortOrder === "ASC" ? "升序" : "降序"}
            >
              <ArrowUpDown className={`w-4 h-4 transition-transform ${sortOrder === "ASC" ? "rotate-180" : ""}`} />
            </button>
          </div>
        </section>

        {/* Content Area Grid (Folders and Files) */}
        <section className="flex-1 flex flex-col gap-6">
          
          {/* A. Folder List (Only show in "all" tab and when no search query is active) */}
          {(activeTab === "all") && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2 px-1">
                <FolderOpen className="w-4.5 h-4.5 text-amber-500" />
                <h2 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">文件夹</h2>
                <span className="text-xs bg-amber-950/30 text-amber-400 px-2 py-0.5 rounded-full font-semibold border border-amber-900/30">{folders.length}</span>
              </div>
              
              {isFetchingContents ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 animate-pulse">
                  {[...Array(4)].map((_, idx) => (
                    <div key={idx} className="p-4 bg-[#111114] border border-[#27272a] rounded-2xl flex items-center gap-3">
                      <div className="p-3 bg-zinc-800 rounded-xl w-11 h-11 shrink-0"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-zinc-800 rounded-md w-3/4"></div>
                        <div className="h-3 bg-zinc-800 rounded-md w-1/2"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : folders.length === 0 ? (
                <p className="text-xs text-zinc-500 italic px-1">当前目录下无子文件夹</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {folders.map((folder) => (
                    <div
                      key={folder.id}
                      onClick={() => navigateToFolder(folder.id, folder.name)}
                      className="group p-4 bg-[#111114] hover:bg-zinc-900/50 border border-[#27272a] hover:border-amber-500/40 rounded-2xl shadow-xs transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 hover:-translate-y-0.5"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="p-3 bg-amber-950/20 text-amber-400 rounded-xl group-hover:bg-amber-900/30 transition-colors shrink-0">
                          <Folder className="w-5 h-5 fill-current" />
                        </div>
                        <div className="min-w-0">
                          <h3 className="text-sm font-semibold text-zinc-200 truncate group-hover:text-amber-400 transition-colors" title={folder.name}>
                            {folder.name}
                          </h3>
                          <p className="text-[10px] text-zinc-500 mt-0.5">{formatDate(folder.created_at)}</p>
                        </div>
                      </div>

                      {/* Folder Actions (Rename / Delete / Restore) */}
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {activeTab === "trash" ? (
                          <>
                            <button
                              onClick={(e) => handleRestoreFolder(folder.id, e)}
                              className="p-1.5 hover:bg-emerald-950/30 rounded-lg text-zinc-400 hover:text-emerald-400 transition-colors cursor-pointer"
                              title="恢复文件夹"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={(e) => handlePermanentlyDeleteFolder(folder.id, e)}
                              className="p-1.5 hover:bg-rose-950/30 rounded-lg text-zinc-400 hover:text-rose-400 transition-colors cursor-pointer"
                              title="永久删除"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setRenameTargetFolder(folder);
                                setRenameInputName(folder.name);
                              }}
                              className="p-1.5 hover:bg-zinc-850 rounded-lg text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
                              title="重命名"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={(e) => handleDeleteFolder(folder.id, e)}
                              className="p-1.5 hover:bg-rose-950/30 rounded-lg text-zinc-400 hover:text-rose-400 transition-colors cursor-pointer"
                              title="移动到回收站"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* C. Shared Links Tab Content */}
          {activeTab === "shared-links" && (
            <div className="flex flex-col gap-4">
              {/* Add New Shared Link Form */}
              <div className="bg-[#111114] border border-[#27272a] rounded-2xl p-4">
                <h3 className="text-sm font-semibold text-zinc-200 mb-3 flex items-center gap-2">
                  <PlusCircle className="w-4.5 h-4.5 text-sky-400" />
                  添加分享链接索引
                </h3>
                <SharedLinkForm onSuccess={() => fetchSharedLinks(1, sharedLinksSearch)} />
              </div>

              {/* Search Box for Shared Links */}
              <div className="relative">
                <Search className="w-5 h-5 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="搜索分享链接（名称或链接）..."
                  value={sharedLinksSearch}
                  onChange={(e) => setSharedLinksSearch(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      setSharedLinksPage(1);
                      fetchSharedLinks(1, e.target.value);
                    }
                  }}
                  className="w-full pl-11 pr-10 py-2.5 bg-[#18181b] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/25 focus:border-[#3b82f6] transition-all placeholder:text-zinc-500"
                />
              </div>

              {/* Shared Links List */}
              <div className="flex flex-col gap-2">
                {sharedLinksLoading && sharedLinks.length === 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 animate-pulse">
                    {[...Array(4)].map((_, idx) => (
                      <div key={idx} className="p-4 bg-[#111114] border border-[#27272a] rounded-2xl flex items-center gap-3">
                        <div className="p-3 bg-zinc-800 rounded-xl w-11 h-11 shrink-0"></div>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-zinc-800 rounded-md w-3/4"></div>
                          <div className="h-3 bg-zinc-800 rounded-md w-1/2"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : sharedLinks.length === 0 ? (
                  <div className="text-center py-12 bg-[#111114] border border-[#27272a] rounded-2xl">
                    <Share2 className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
                    <p className="text-zinc-400">暂无分享链接索引</p>
                    <p className="text-xs text-zinc-500 mt-1">点击上方「添加分享链接索引」创建</p>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {sharedLinks.map((link) => (
                        <SharedLinkCard 
                          key={link.id} 
                          link={link} 
                          onDelete={() => {
                            if (confirm("确定删除该分享链接索引吗？")) {
                              handleDeleteSharedLink(link.id);
                            }
                          }}
                        />
                      ))}
                    </div>

                    {/* Load More / Pagination */}
                    {sharedLinks.length < sharedLinksTotal && (
                      <div className="flex justify-center pt-2">
                        <button
                          onClick={() => {
                            const nextPage = sharedLinksPage + 1;
                            setSharedLinksPage(nextPage);
                            fetchSharedLinks(nextPage, sharedLinksSearch);
                          }}
                          disabled={sharedLinksLoading}
                          className="px-6 py-2.5 bg-sky-950/40 hover:bg-sky-950/60 text-sky-400 border border-sky-900/40 font-medium text-sm rounded-xl transition-all cursor-pointer disabled:opacity-50"
                        >
                          {sharedLinksLoading ? (
                            <>
                              <span className="animate-spin mr-2">⏳</span> 加载中...
                            </>
                          ) : (
                            `加载更多 (${sharedLinks.length} / ${sharedLinksTotal})`
                          )}
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}

          {/* B. File List (Card layout - Waterfall Flow) */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2 px-1">
              <File className="w-4.5 h-4.5 text-[#3b82f6]" />
              <h2 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">{getFileHeaderLabel()}</h2>
              <span className="text-xs bg-blue-950/30 text-[#3b82f6] px-2 py-0.5 rounded-full font-semibold border border-[#3b82f6]/20">
                {files.length}{hasMore ? "+" : ""}
              </span>
            </div>

            {isFetchingContents ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 animate-pulse">
                {[...Array(8)].map((_, idx) => (
                  <div key={idx} className="bg-[#111114] border border-[#27272a] rounded-2xl overflow-hidden h-[300px] flex flex-col">
                    <div className="h-44 bg-zinc-800"></div>
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="h-4 bg-zinc-800 rounded-md w-3/4"></div>
                        <div className="h-3 bg-zinc-800 rounded-md w-1/2"></div>
                      </div>
                      <div className="h-6 bg-zinc-800 rounded-md w-1/3 mt-4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : files.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 bg-[#111114] rounded-3xl border border-dashed border-[#27272a]">
                <div className="w-16 h-16 rounded-full bg-[#18181b] text-zinc-500 flex items-center justify-center mb-4">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="text-zinc-300 font-semibold text-sm">暂无匹配文件</h3>
                <p className="text-xs text-zinc-500 mt-1 max-w-xs text-center leading-relaxed">
                  {searchQuery 
                    ? "未找到与搜索内容相符的文件，请尝试重新输入" 
                    : "当前文件夹为空，点击右上角「上传文件」或将文件直接拖放到页面任何位置。"}
                </p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 w-full">
                  {files.map((file) => {
                    const style = getFileStyleAndIcon(file.mime_type);
                    const IconComponent = style.icon;
                    const isFav = file.is_favorite === 1;

                    return (
                      <div
                        key={file.id}
                        className="bg-[#111114] border border-[#27272a] hover:border-[#3b82f6]/40 rounded-2xl shadow-xs hover:shadow-lg transition-all duration-200 overflow-hidden flex flex-col hover:-translate-y-1 relative"
                      >
                        {/* Favorite Button (Star overlay) */}
                        <button
                          onClick={(e) => toggleFavorite(file, e)}
                          className={`absolute top-3 left-3 p-1.5 rounded-full z-10 transition-colors cursor-pointer ${
                            isFav 
                              ? "bg-amber-500/10 text-amber-400 opacity-100" 
                              : "bg-black/40 backdrop-blur-md text-white md:opacity-0 md:group-hover:opacity-100 hover:bg-black/60"
                          }`}
                          title={isFav ? "取消收藏" : "加入收藏"}
                        >
                          <Star className={`w-4 h-4 ${isFav ? "fill-current" : ""}`} />
                        </button>

                        {/* Category Badge overlay */}
                        <span className={`absolute top-3 right-3 text-[10px] font-semibold px-2 py-0.5 rounded-md uppercase tracking-wider backdrop-blur-md ${style.bgClass} border z-10`}>
                          {style.badge}
                        </span>

                        {/* Card Thumbnail / Preview Header with Waterfall Varying Heights */}
                        <div 
                          onClick={() => openFilePreview(file)}
                          className={`bg-[#18181b] border-b border-[#27272a] relative flex items-center justify-center overflow-hidden cursor-pointer group-hover:bg-[#1f1f23] transition-colors ${
                            file.mime_type.startsWith("image/") 
                              ? "h-56" 
                              : file.mime_type.startsWith("video/") 
                                ? "h-40" 
                                : "h-32"
                          }`}
                        >
                          {file.mime_type.startsWith("image/") ? (
                            <img
                              src={`/api/files/thumbnail/${file.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                              alt={file.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              loading="lazy"
                            />
                          ) : file.mime_type.startsWith("video/") ? (
                            <div className="w-full h-full relative flex items-center justify-center bg-black text-white">
                              <img
                                src={`/api/files/thumbnail/${file.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                                alt={file.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-60"
                                loading="lazy"
                              />
                              {/* Overlay play button */}
                              <div className="absolute w-12 h-12 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:scale-110 group-hover:bg-[#3b82f6] transition-all shadow-md">
                                <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                              </div>
                              <VideoIcon className="w-10 h-10 text-white/40 absolute bottom-3 left-3" />
                            </div>
                          ) : (
                            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${style.bgClass} border`}>
                              <IconComponent className="w-8 h-8" />
                            </div>
                          )}

                          {/* Interactive overlay on hover */}
                          <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                openFilePreview(file);
                              }}
                              className="px-3.5 py-1.5 bg-black/60 text-white font-semibold text-xs rounded-lg shadow-sm hover:bg-black/85 transition-colors cursor-pointer"
                            >
                              预览
                            </button>
                          </div>
                        </div>

                        {/* Card Information Body */}
                        <div className="p-4 flex flex-col gap-2 min-w-0 flex-1">
                          <div className="min-w-0">
                            <h3 
                              onClick={() => openFilePreview(file)}
                              className="text-sm font-semibold text-zinc-200 line-clamp-2 hover:text-[#3b82f6] transition-colors cursor-pointer" 
                              title={file.name}
                            >
                              {file.name}
                            </h3>
                            <div className="flex items-center gap-1.5 text-[11px] text-zinc-500 mt-1 font-medium font-mono">
                              <span>{formatBytes(file.size)}</span>
                              <span>•</span>
                              <span>{formatDate(file.created_at)}</span>
                            </div>
                          </div>

                          {/* Card Action Buttons footer */}
                          <div className="flex items-center justify-between border-t border-[#27272a] pt-3 mt-auto">
                            {activeTab === "trash" ? (
                              <>
                                <button
                                  onClick={(e) => handleRestoreFile(file.id, e)}
                                  className="flex items-center gap-1 px-2 py-1.5 bg-emerald-950/20 hover:bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 text-xs font-semibold rounded-lg transition-all cursor-pointer shadow-xs shrink-0"
                                  title="恢复文件"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                  <span>恢复</span>
                                </button>
                                <button
                                  onClick={(e) => handlePermanentlyDeleteFile(file.id, e)}
                                  className="flex items-center gap-1 px-2 py-1.5 bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/30 text-rose-400 text-xs font-semibold rounded-lg transition-all cursor-pointer shadow-xs shrink-0"
                                  title="永久删除"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>永久删除</span>
                                </button>
                              </>
                            ) : (
                              <>
                                <a
                                  href={`/api/files/download/${file.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                                  download
                                  onClick={(e) => e.stopPropagation()}
                                  className="p-2 text-zinc-400 hover:text-[#3b82f6] hover:bg-zinc-900 rounded-lg transition-colors cursor-pointer"
                                  title="下载"
                                >
                                  <Download className="w-4.5 h-4.5" />
                                </a>

                                <div className="flex items-center gap-0.5">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openMoveCopyModal(file, "move");
                                    }}
                                    className="p-2 text-zinc-400 hover:text-amber-400 hover:bg-zinc-900 rounded-lg transition-colors cursor-pointer"
                                    title="移动到..."
                                  >
                                    <FolderInput className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openMoveCopyModal(file, "copy");
                                    }}
                                    className="p-2 text-zinc-400 hover:text-indigo-400 hover:bg-zinc-900 rounded-lg transition-colors cursor-pointer"
                                    title="复制到..."
                                  >
                                    <Copy className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setRenameTargetFile(file);
                                      setRenameInputName(file.name);
                                    }}
                                    className="p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900 rounded-lg transition-colors cursor-pointer"
                                    title="重命名"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={(e) => handleDeleteFile(file.id, e)}
                                    className="p-2 text-zinc-400 hover:text-rose-400 hover:bg-rose-950/20 rounded-lg transition-colors cursor-pointer"
                                    title="移动到回收站"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Infinite Scroll trigger target */}
                {hasMore && (
                  <div ref={observerTarget} className="flex justify-center py-6">
                    {isLoadingMore ? (
                      <div className="flex items-center gap-2 text-blue-400 animate-pulse">
                        <svg className="animate-spin h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span className="text-sm font-medium text-zinc-400">正在加载更多文件...</span>
                      </div>
                    ) : (
                      <button 
                        onClick={loadMoreFiles} 
                        className="text-xs text-[#3b82f6] hover:text-blue-400 font-semibold cursor-pointer py-2 px-4 rounded-xl bg-blue-950/20 border border-blue-900/30 hover:bg-blue-950/40 transition-colors"
                      >
                        加载更多文件
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>

        </section>

      </main>

      {/* ==========================================
          5. DIALOGS & MODAL OVERLAYS
          ========================================== */}
      
      {/* A. NEW FOLDER MODAL */}
      <AnimatePresence>
        {isNewFolderOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#18181b] rounded-2xl border border-[#27272a] max-w-sm w-full p-6 shadow-2xl flex flex-col gap-4 text-[#fafafa]"
            >
              <div className="flex justify-between items-center pb-2 border-b border-[#27272a]">
                <h3 className="font-bold text-white text-base">新建文件夹</h3>
                <button onClick={() => setIsNewFolderOpen(false)} className="text-zinc-500 hover:text-zinc-300 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateFolder} className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-zinc-400">文件夹名称</label>
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="请输入文件夹名称"
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111114] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/20 focus:border-[#3b82f6] transition-all placeholder:text-zinc-500"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsNewFolderOpen(false)}
                    className="px-4 py-2 bg-transparent hover:bg-zinc-800 text-zinc-300 font-semibold text-xs rounded-xl border border-[#27272a] transition-colors cursor-pointer"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#3b82f6] hover:bg-blue-600 text-white font-semibold text-xs rounded-xl shadow-lg shadow-blue-500/10 transition-colors cursor-pointer"
                  >
                    新建
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* B. RENAME FILE MODAL */}
      <AnimatePresence>
        {renameTargetFile && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#18181b] rounded-2xl border border-[#27272a] max-w-sm w-full p-6 shadow-2xl flex flex-col gap-4 text-[#fafafa]"
            >
              <div className="flex justify-between items-center pb-2 border-b border-[#27272a]">
                <h3 className="font-bold text-white text-base">重命名文件</h3>
                <button onClick={() => setRenameTargetFile(null)} className="text-zinc-500 hover:text-zinc-300 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleRenameFileSubmit} className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-zinc-400">文件名称</label>
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="请输入新名称"
                    value={renameInputName}
                    onChange={(e) => setRenameInputName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111114] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/20 focus:border-[#3b82f6] transition-all placeholder:text-zinc-500"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setRenameTargetFile(null)}
                    className="px-4 py-2 bg-transparent hover:bg-zinc-800 text-zinc-300 font-semibold text-xs rounded-xl border border-[#27272a] transition-colors cursor-pointer"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#3b82f6] hover:bg-blue-600 text-white font-semibold text-xs rounded-xl shadow-lg shadow-blue-500/10 transition-colors cursor-pointer"
                  >
                    保存
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* C. RENAME FOLDER MODAL */}
      <AnimatePresence>
        {renameTargetFolder && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#18181b] rounded-2xl border border-[#27272a] max-w-sm w-full p-6 shadow-2xl flex flex-col gap-4 text-[#fafafa]"
            >
              <div className="flex justify-between items-center pb-2 border-b border-[#27272a]">
                <h3 className="font-bold text-white text-base">重命名文件夹</h3>
                <button onClick={() => setRenameTargetFolder(null)} className="text-zinc-500 hover:text-zinc-300 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleRenameFolderSubmit} className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-zinc-400">文件夹名称</label>
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="请输入新文件夹名称"
                    value={renameInputName}
                    onChange={(e) => setRenameInputName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#111114] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/20 focus:border-[#3b82f6] transition-all placeholder:text-zinc-500"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setRenameTargetFolder(null)}
                    className="px-4 py-2 bg-transparent hover:bg-zinc-800 text-zinc-300 font-semibold text-xs rounded-xl border border-[#27272a] transition-colors cursor-pointer"
                  >
                    取消
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#3b82f6] hover:bg-blue-600 text-white font-semibold text-xs rounded-xl shadow-lg shadow-blue-500/10 transition-colors cursor-pointer"
                  >
                    保存
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* D. INTERACTIVE MULTIMEDIA PREVIEW MODAL */}
      <AnimatePresence>
        {previewFile && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 md:p-8 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="bg-[#111114] border border-[#27272a] rounded-3xl w-full max-w-5xl overflow-hidden flex flex-col md:flex-row h-[85vh] md:h-[80vh] shadow-2xl relative"
            >
              {/* Media viewer panel */}
              <div className="flex-1 bg-black flex flex-col relative items-center justify-center p-4 min-w-0">
                
                {/* Unified floating top controls */}
                <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-[101] pointer-events-none">
                  {/* Close button on left */}
                  <button
                    onClick={() => setPreviewFile(null)}
                    className="pointer-events-auto p-2 bg-[#18181b]/80 hover:bg-[#27272a]/90 border border-[#27272a] text-white rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    title="关闭预览"
                  >
                    <X className="w-5 h-5" />
                    <span className="text-xs pr-1 font-semibold hidden sm:inline">关闭</span>
                  </button>

                  {/* Sidebar / details toggle button on right */}
                  <button
                    onClick={() => setShowPreviewSidebar(prev => !prev)}
                    className={`pointer-events-auto p-2 bg-[#18181b]/80 hover:bg-[#27272a]/90 border border-[#27272a] text-white rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      showPreviewSidebar ? 'ring-2 ring-[#3b82f6]/50 border-[#3b82f6]' : ''
                    }`}
                    title="文件详情"
                  >
                    <Info className="w-5 h-5 text-[#3b82f6]" />
                    <span className="text-xs font-semibold hidden sm:inline">
                      {showPreviewSidebar ? "隐藏详情" : "显示详情"}
                    </span>
                  </button>
                </div>

                {/* Media-specific visual elements */}
                {previewFile.mime_type.startsWith("image/") ? (
                  <div 
                    ref={imgContainerRef}
                    onMouseMove={handleImgMouseMove}
                    onMouseUp={handleImgMouseUp}
                    onMouseLeave={handleImgMouseUp}
                    onTouchMove={handleImgTouchMove}
                    onTouchEnd={handleImgMouseUp}
                    className={`relative flex items-center justify-center overflow-hidden transition-all duration-300 touch-none ${
                      isImageFullscreen 
                        ? "fixed inset-0 bg-black/95 z-[100] w-screen h-screen" 
                        : "w-full flex-1 min-h-0"
                    }`}
                  >
                    {isImageFullscreen && (
                      <button
                        onClick={() => setIsImageFullscreen(false)}
                        className="absolute top-6 right-6 p-2.5 bg-[#18181b]/80 hover:bg-[#27272a]/90 border border-[#27272a] text-white rounded-full shadow-lg transition-all cursor-pointer z-[101]"
                        title="退出全屏"
                      >
                        <Minimize2 className="w-5 h-5" />
                      </button>
                    )}

                    <img
                      src={`/api/files/raw/${previewFile.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                      alt={previewFile.name}
                      referrerPolicy="no-referrer"
                      onMouseDown={handleImgMouseDown}
                      onTouchStart={handleImgTouchStart}
                      onDoubleClick={handleImgDoubleClick}
                      style={{ 
                        transform: `translate(${imageOffset.x}px, ${imageOffset.y}px) scale(${imageZoom}) rotate(${imageRotation}deg)`,
                        transition: isDraggingImage ? "none" : "transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)",
                        cursor: isDraggingImage ? "grabbing" : "grab"
                      }}
                      className="max-w-full max-h-full object-contain select-none touch-none"
                    />

                    {/* Image manipulations bar */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#18181b]/95 backdrop-blur-md px-3 sm:px-4 py-1.5 sm:py-2 rounded-full border border-[#27272a] flex items-center gap-2 sm:gap-4 text-white z-[101] max-w-[90vw] overflow-x-auto whitespace-nowrap scrollbar-none">
                      <button 
                        onClick={() => {
                          setImageZoom(Math.max(0.4, imageZoom - 0.2));
                          setImageOffset({ x: 0, y: 0 });
                        }} 
                        className="p-2 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                        title="缩小"
                      >
                        <ZoomOut className="w-5 h-5" />
                      </button>
                      <span className="text-xs font-mono font-semibold select-none">{(imageZoom * 100).toFixed(0)}%</span>
                      <button 
                        onClick={() => {
                          setImageZoom(Math.min(6, imageZoom + 0.2));
                        }} 
                        className="p-2 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                        title="放大"
                      >
                        <ZoomIn className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => {
                          setImageZoom(1);
                          setImageOffset({ x: 0, y: 0 });
                        }} 
                        className="text-sm font-medium px-3 py-1.5 hover:bg-zinc-800 rounded-md text-zinc-300 transition-colors"
                        title="重置"
                      >
                        重置
                      </button>
                      <div className="w-[1px] h-5 bg-zinc-800" />
                      <button 
                        onClick={() => setImageRotation((imageRotation + 90) % 360)} 
                        className="p-2 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                        title="旋转"
                      >
                        <RotateCw className="w-5 h-5" />
                      </button>
                      <div className="w-[1px] h-5 bg-zinc-800" />
                      <button 
                        onClick={() => setIsImageFullscreen(!isImageFullscreen)} 
                        className="p-2 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                        title={isImageFullscreen ? "退出全屏" : "全屏预览"}
                      >
                        {isImageFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                ) : previewFile.mime_type.startsWith("video/") ? (
                  <div className="w-full h-full flex items-center justify-center relative pt-12">
                    <video
                      src={`/api/files/raw/${previewFile.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                      controls
                      autoPlay
                      preload="auto"
                      className="max-w-full max-h-[80%] rounded-lg shadow-2xl"
                    />
                  </div>
                ) : previewFile.mime_type.startsWith("audio/") ? (
                  <div className="flex flex-col items-center gap-6 w-full max-w-md text-center pt-12">
                    <div className="relative w-44 h-44 rounded-full bg-[#18181b] border-4 border-[#27272a] flex items-center justify-center shadow-xl overflow-hidden group">
                      {/* CD Vinyl design spinning */}
                      <div className="absolute inset-0 rounded-full border-12 border-dashed border-[#3b82f6]/20 animate-spin [animation-duration:15s]" />
                      <MusicIcon className="w-16 h-16 text-[#3b82f6]" />
                    </div>
                    <div className="w-full">
                      <p className="text-white font-semibold text-base px-4 truncate">{previewFile.name}</p>
                      <p className="text-[#3b82f6] text-xs font-mono font-medium mt-1">音频流式播放器</p>
                    </div>
                    <audio
                      src={`/api/files/raw/${previewFile.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                      controls
                      autoPlay
                      className="w-full"
                    />
                  </div>
                ) : (previewFile.mime_type.startsWith("text/") || previewFile.mime_type === "application/json") ? (
                  <div className="w-full h-full flex flex-col p-4 pt-16">
                    <div className="flex justify-between items-center pb-2 mb-2 border-b border-[#27272a]">
                      <span className="text-xs font-bold text-zinc-500 font-mono">文本预览 (PREVIEW)</span>
                    </div>
                    <div className="flex-1 bg-black p-4 rounded-xl overflow-auto border border-[#27272a]">
                      {previewTextContent !== null ? (
                        <pre className="text-zinc-200 text-xs font-mono whitespace-pre-wrap text-left leading-relaxed">
                          {previewTextContent}
                        </pre>
                      ) : (
                        <div className="text-zinc-500 text-xs text-center py-12 flex flex-col items-center gap-2">
                          <span className="inline-block w-4 h-4 border-2 border-zinc-500 border-t-transparent rounded-full animate-spin" />
                          <span>正在加载文件内容...</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-4 text-center pt-12">
                    <div className="p-6 bg-[#18181b] rounded-3xl border border-[#27272a] text-zinc-400">
                      <FileCode className="w-12 h-12" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold text-sm">{previewFile.name}</h4>
                      <p className="text-xs text-zinc-400 mt-1">此类型文件不支持直接在浏览器中预览</p>
                    </div>
                    <a
                      href={`/api/files/download/${previewFile.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                      download
                      className="px-5 py-2.5 bg-[#3b82f6] hover:bg-blue-600 text-white font-semibold text-xs rounded-xl shadow-lg shadow-blue-900/30 transition-colors"
                    >
                      下载文件查看
                    </a>
                  </div>
                )}
              </div>

              {/* Sidebar information panel - toggleable */}
              <div className={`${showPreviewSidebar ? "flex" : "hidden"} w-full md:w-80 bg-[#111114] border-t md:border-t-0 md:border-l border-[#27272a] p-6 flex-col gap-6 shrink-0 text-zinc-300 md:max-h-full overflow-y-auto`}>
                
                {/* Header info */}
                <div className="flex items-start justify-between pb-4 border-b border-[#27272a]">
                  <div className="min-w-0">
                    <h3 className="font-bold text-white text-base truncate" title={previewFile.name}>
                      {previewFile.name}
                    </h3>
                    <p className="text-xs text-zinc-500 font-mono mt-1 uppercase tracking-wider">{previewFile.mime_type}</p>
                  </div>
                </div>

                {/* Properties details */}
                <div className="flex flex-col gap-4 flex-1">
                  <h4 className="text-[11px] font-bold text-zinc-500 tracking-wider uppercase">文件详情</h4>
                  
                  <div className="grid grid-cols-1 gap-3.5 text-xs">
                    <div className="flex justify-between items-center bg-[#18181b]/50 p-2.5 rounded-xl border border-[#27272a]">
                      <span className="text-zinc-400 font-medium flex items-center gap-1.5"><Info className="w-3.5 h-3.5 text-[#3b82f6]" /> 大小</span>
                      <span className="font-semibold text-zinc-200 font-mono">{formatBytes(previewFile.size)}</span>
                    </div>

                    <div className="flex justify-between items-center bg-[#18181b]/50 p-2.5 rounded-xl border border-[#27272a]">
                      <span className="text-zinc-400 font-medium flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-[#3b82f6]" /> 上传时间</span>
                      <span className="font-semibold text-zinc-200">{formatDate(previewFile.created_at)}</span>
                    </div>

                    <div className="flex justify-between items-center bg-[#18181b]/50 p-2.5 rounded-xl border border-[#27272a]">
                      <span className="text-zinc-400 font-medium flex items-center gap-1.5"><Star className="w-3.5 h-3.5 text-[#3b82f6]" /> 收藏状态</span>
                      <span className="font-semibold text-zinc-200">{previewFile.is_favorite === 1 ? "已收藏" : "未收藏"}</span>
                    </div>
                  </div>
                </div>

                {/* Footer action controls */}
                <div className="flex gap-3 pt-4 border-t border-[#27272a] mt-auto">
                  <button
                    onClick={(e) => handleDeleteFile(previewFile.id, e as any)}
                    className="flex-1 py-2.5 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white font-semibold text-xs rounded-xl border border-rose-500/20 hover:border-rose-500 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>删除</span>
                  </button>
                  
                  <a
                    href={`/api/files/download/${previewFile.id}?token=${authToken || localStorage.getItem("auth_token")}`}
                    download
                    className="flex-1 py-2.5 bg-[#3b82f6] hover:bg-blue-600 text-white font-semibold text-xs rounded-xl shadow-md shadow-blue-950/20 hover:shadow-blue-950/40 transition-all cursor-pointer flex items-center justify-center gap-1.5 text-center"
                  >
                    <Download className="w-4 h-4" />
                    <span>下载</span>
                  </a>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating Resumable Upload Status Panel */}
      <AnimatePresence>
        {isUploading && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-sm sm:max-w-md sm:left-auto sm:translate-x-0 sm:bottom-6 sm:right-6 sm:w-96 bg-[#111114] border border-[#27272a] rounded-2xl shadow-2xl p-4 z-50 overflow-hidden flex flex-col gap-3"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-[#27272a] pb-2">
              <span className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-[#3b82f6] animate-bounce" />
                正在传输分片
              </span>
              <div className="flex items-center gap-1.5">
                {/* Pause/Resume Button */}
                <button
                  onClick={() => {
                    const nextPauseState = !isUploadPaused;
                    setIsUploadPaused(nextPauseState);
                    isUploadPausedRef.current = nextPauseState;
                  }}
                  className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-colors cursor-pointer flex items-center justify-center"
                  title={isUploadPaused ? "继续上传" : "暂停上传"}
                >
                  {isUploadPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4" />}
                </button>
                {/* Cancel Button */}
                <button
                  onClick={() => {
                    if (confirm("确定要取消本次上传吗？已上传的部分分片可以保留供下次快速续传。")) {
                      setUploadCancelRequested(true);
                      uploadCancelRequestedRef.current = true;
                    }
                  }}
                  className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-rose-400 rounded-lg transition-colors cursor-pointer flex items-center justify-center"
                  title="取消上传"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Info */}
            <div className="flex flex-col gap-1">
              <p className="text-sm font-semibold text-white truncate" title={uploadingFileName}>
                {uploadingFileName || "准备中..."}
              </p>
              <div className="flex items-center justify-between text-[11px] text-zinc-400 font-mono">
                <span>{isUploadPaused ? "已暂停" : uploadSpeed}</span>
                <span>{uploadProgress}%</span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-[#18181b] h-2 rounded-full overflow-hidden border border-[#27272a]">
              <div 
                className={`h-full rounded-full transition-all duration-300 ${isUploadPaused ? 'bg-amber-500' : 'bg-[#3b82f6]'}`}
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            
            <p className="text-[10px] text-zinc-500 italic">
              支持分片断点续传，可在断开连接后重新上传同一文件自动极速续传。
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* E. SETTINGS MODAL */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#18181b] rounded-2xl border border-[#27272a] max-w-md w-full p-6 shadow-2xl flex flex-col gap-4 text-[#fafafa]"
            >
              <div className="flex justify-between items-center pb-2 border-b border-[#27272a]">
                <h3 className="font-bold text-white text-base">上传设置</h3>
                <button onClick={() => setIsSettingsOpen(false)} className="text-zinc-500 hover:text-zinc-300 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-zinc-400 flex items-center gap-1.5">
                    <Settings className="w-3.5 h-3.5 text-sky-400" />
                    分片大小
                  </label>
                  <p className="text-[11px] text-zinc-500">
                    单个分片的大小（MB）。大文件上传时，文件会被切割成多个该大小的分片并行上传。
                    较大的分片可减少请求数，较小的分片更利于断点续传。
                  </p>
                  <div className="flex gap-2">
                    <select
                      value={chunkSize}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        setChunkSize(val);
                        localStorage.setItem("upload_chunk_size_mb", String(val));
                      }}
                      className="flex-1 px-3.5 py-2.5 bg-[#111114] border border-[#27272a] rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#3b82f6]/20 focus:border-[#3b82f6] transition-all appearance-none bg-no-repeat bg-right"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%2371717a' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
                        backgroundPosition: 'right 0.75rem center',
                        backgroundSize: '1.5em 1.5em',
                        paddingRight: '2.5rem',
                      }}
                    >
                      <option value={5}>5 MB（小文件、弱网环境）</option>
                      <option value={10}>10 MB（平衡）</option>
                      <option value={30}>30 MB（默认，推荐大文件）</option>
                      <option value={50}>50 MB（大文件、高速网络）</option>
                      <option value={100}>100 MB（极大文件、极速网络）</option>
                    </select>
                    <span className="flex items-center text-zinc-400 text-xs px-2">MB</span>
                  </div>
                  <p className="text-[11px] text-emerald-400 font-medium">
                    当前设置：{chunkSize} MB / 片
                  </p>
                </div>
              </div>

              <div className="flex justify-end gap-2.5 pt-2 border-t border-[#27272a]">
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="px-4 py-2 bg-transparent hover:bg-zinc-800 text-zinc-300 font-semibold text-xs rounded-xl border border-[#27272a] transition-colors cursor-pointer"
                >
                  关闭
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
