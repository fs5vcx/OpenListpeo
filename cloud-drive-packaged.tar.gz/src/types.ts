export interface Folder {
  id: string;
  name: string;
  parent_id: string;
  created_at: string;
}

export interface DriveFile {
  id: string;
  name: string;
  original_name: string;
  mime_type: string;
  size: number;
  path: string;
  thumbnail_path?: string;
  created_at: string;
  folder_id: string;
  is_favorite: number; // 0 or 1 (represented as integer in SQLite)
  tags?: string;
}

export interface StorageCategory {
  size: number;
  count: number;
}

export interface DriveStats {
  totalSize: number;
  totalCount: number;
  categories: {
    images: StorageCategory;
    videos: StorageCategory;
    audio: StorageCategory;
    documents: StorageCategory;
    others: StorageCategory;
  };
}

// Shared Link for PikPak indexing
export interface SharedLink {
  id: string;
  name: string;
  share_url: string;
  pikpak_id: string;
  size: number;
  format?: string;
  created_at: string;
}
