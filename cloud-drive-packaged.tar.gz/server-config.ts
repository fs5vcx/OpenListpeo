import path from "path";
import dotenv from "dotenv";

// Load environment variables from .env file if present
dotenv.config();

const workspaceRoot = process.cwd();

export const config = {
  // Server Configuration
  port: parseInt(process.env.PORT || "3000", 10),
  
  // Database Configuration
  dbPath: process.env.DATABASE_FILE || path.join(workspaceRoot, "drive.db"),
  
  // Storage & Directory Configuration
  uploadDir: process.env.STORAGE_DIR || path.join(workspaceRoot, "uploads"),
  
  // Security Configurations
  sessionSecret: process.env.SESSION_SECRET || "super-secret-personal-cloud-drive-session-key",
  
  // General App Metadata
  appName: process.env.APP_NAME || "个人云盘",
};
