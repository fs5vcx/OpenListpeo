const fs = require('fs');
let c = fs.readFileSync('/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/default/cloud-drive/server.ts', 'utf8');

// 替换图片缩略图生成逻辑，增加视频支持
const oldLogic = `let thumbnailPath = "";
          if (mimeType.startsWith("image/")) {
            thumbnailPath = \`/api/files/raw/\${fileId}\`;
          }`;

const newLogic = `let thumbnailPath = "";
          if (mimeType.startsWith("image/")) {
            thumbnailPath = \`/api/files/raw/\${fileId}\`;
          } else if (mimeType.startsWith("video/")) {
            // 生成视频缩略图
            thumbnailPath = \`/api/files/thumbnail/\${fileId}\`;
          }`;

c = c.replace(oldLogic, newLogic);

fs.writeFileSync('/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/default/cloud-drive/server.ts', c);
console.log('Fixed video thumbnails!');