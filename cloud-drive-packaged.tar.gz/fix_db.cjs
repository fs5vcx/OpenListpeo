const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

// 添加 file_contents 表
const fileContentsTable = `  CREATE TABLE IF NOT EXISTS file_contents (
    content_hash TEXT PRIMARY KEY,
    path TEXT NOT NULL,
    size INTEGER NOT NULL,
    ref_count INTEGER DEFAULT 1,
    created_at TEXT NOT NULL,
    original_name TEXT NOT NULL
  );
`;

// 在 files 表前面插入
const marker = 'CREATE TABLE IF NOT EXISTS files';
const newContent = content.replace(
  marker,
  fileContentsTable + '\n  ' + marker
);

fs.writeFileSync('server.ts', newContent);
console.log('Fixed!');