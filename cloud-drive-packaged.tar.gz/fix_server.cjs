const fs = require('fs');
let c = fs.readFileSync('/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/default/cloud-drive/server.ts', 'utf8');

// 添加 file_contents 表
const fc = `\n  CREATE TABLE IF NOT EXISTS file_contents (
    content_hash TEXT PRIMARY KEY,
    path TEXT NOT NULL,
    size INTEGER NOT NULL,
    ref_count INTEGER DEFAULT 1,
    created_at TEXT NOT NULL,
    original_name TEXT NOT NULL
  );`;
c = c.replace('CREATE TABLE IF NOT EXISTS files', fc + '\n\n  CREATE TABLE IF NOT EXISTS files');

// 添加 content_hash 列到 files 表
c = c.replace('is_trashed INTEGER DEFAULT 0\n  );', 'is_trashed INTEGER DEFAULT 0,\n    content_hash TEXT\n  );');

// 添加 content_hash 迁移
const m = `try {
  db.exec("ALTER TABLE files ADD COLUMN is_trashed INTEGER DEFAULT 0");
} catch (e) {}`;
c = c.replace(m, m + '\n\ntry {\n  db.exec("ALTER TABLE files ADD COLUMN content_hash TEXT");\n} catch (e) {}');

fs.writeFileSync('/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/default/cloud-drive/server.ts', c);
console.log('Fixed!');