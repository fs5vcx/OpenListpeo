const Database = require('better-sqlite3');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const dbPath = '/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/UserStorage/personal-cloud-drive/db/drive.db';
const uploadDir = '/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/UserStorage/personal-cloud-drive/uploads';

const db = new Database(dbPath);

// 查找所有重复内容组
const duplicates = db.prepare(`
  SELECT content_hash, COUNT(*) as cnt, SUM(size) as total_size
  FROM files 
  WHERE content_hash IS NOT NULL AND content_hash != ''
  GROUP BY content_hash 
  HAVING cnt > 1
`).all();

console.log(`发现 ${duplicates.length} 组重复内容`);
let totalFreed = 0;

for (const dup of duplicates) {
  // 获取该哈希下的所有文件记录
  const files = db.prepare(`
    SELECT id, name, path, size, folder_id, created_at
    FROM files 
    WHERE content_hash = ?
    ORDER BY created_at ASC
  `).all(dup.content_hash);
  
  console.log(`\n处理 Hash ${dup.content_hash.substring(0,16)}... (${files.length} 个文件)`);
  
  // 保留最早的文件（引用计数最大的）
  const keepFile = files[0];
  const content = db.prepare("SELECT * FROM file_contents WHERE content_hash = ?").get(dup.content_hash);
  
  // 更新 file_contents 的 path 指向保留的文件，ref_count = 实际引用数
  const refCount = files.length;
  db.prepare("UPDATE file_contents SET path = ?, ref_count = ? WHERE content_hash = ?")
    .run(keepFile.path, refCount, dup.content_hash);
  
  console.log(`  保留: ${keepFile.name} (${keepFile.path}) ref_count=${refCount}`);
  
  // 删除其余物理文件和记录
  for (let i = 1; i < files.length; i++) {
    const f = files[i];
    const fullPath = path.join(uploadDir, f.path);
    
    if (fs.existsSync(fullPath)) {
      const sizeMB = (f.size / 1024 / 1024).toFixed(2);
      fs.unlinkSync(fullPath);
      console.log(`  删除物理文件: ${f.name} (${sizeMB} MB)`);
      totalFreed += f.size;
    }
    
    // 删除元数据文件
    const metaPath = fullPath + '.meta.json';
    if (fs.existsSync(metaPath)) fs.unlinkSync(metaPath);
    
    // 删除 files 记录
    db.prepare("DELETE FROM files WHERE id = ?").run(f.id);
    console.log(`  删除数据库记录: ${f.name}`);
  }
  
  // 更新保留文件的 content_hash 确保一致
  db.prepare("UPDATE files SET content_hash = ? WHERE id = ?").run(dup.content_hash, keepFile.id);
}

console.log(`\n=== 清理完成 ===`);
console.log(`释放空间: ${(totalFreed/1024/1024/1024).toFixed(2)} GB`);

// 显示最终统计
const finalStats = db.prepare(`
  SELECT content_hash, COUNT(*) as cnt 
  FROM files 
  WHERE content_hash IS NOT NULL AND content_hash != ''
  GROUP BY content_hash 
  HAVING cnt > 1
`).all();

if (finalStats.length === 0) {
  console.log("✅ 所有重复内容已清理，每个内容只保留一份物理文件");
} else {
  console.log(`⚠️ 剩余 ${finalStats.length} 组重复内容需手动检查`);
}