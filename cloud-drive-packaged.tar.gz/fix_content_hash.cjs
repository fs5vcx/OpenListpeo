const fs = require('fs');
let c = fs.readFileSync('/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/default/cloud-drive/server.ts', 'utf8');
const s = 'ALTER TABLE files ADD COLUMN is_trashed INTEGER DEFAULT 0';
const r = 'ALTER TABLE files ADD COLUMN is_trashed INTEGER DEFAULT 0");\n} catch (e) {}\n\ntry {\n  db.exec("ALTER TABLE files ADD COLUMN content_hash TEXT");\n} catch (e) {}';
if (c.includes(s + '");')) {
  c = c.replace(s + '");', r);
  fs.writeFileSync('/run/csi/mount-root/nas/4079184d856ecc166ed19d4887083405/workspaces/default/cloud-drive/server.ts', c);
  console.log('Fixed!');
} else {
  console.log('Pattern not found');
}